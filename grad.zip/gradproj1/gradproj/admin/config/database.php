<?php
class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        // Load environment variables if not already loaded
        $this->loadEnv();
        
        // Validate required environment variables
        $this->validateEnv();
        
        try {
            $this->pdo = new PDO(
                'mysql:host=' . getenv('DB_HOST') . ';dbname=' . getenv('DB_NAME') . ';charset=utf8mb4',
                getenv('DB_USER'),
                getenv('DB_PASS'),
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_PERSISTENT => false, // Important for production
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+00:00'", // UTC timezone
                    PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT => false, // Only for development!
                ]
            );
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new RuntimeException("Database connection error. Please try again later.");
        }
    }
    
    private function loadEnv() {
        // Only load if not in production (where env vars are set differently)
        if (getenv('APP_ENV') !== 'production' && file_exists(__DIR__ . '/../.env')) {
            $lines = file(__DIR__ . '/../.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            foreach ($lines as $line) {
                if (strpos(trim($line), '#') === 0) continue;
                
                list($name, $value) = explode('=', $line, 2);
                putenv(trim($name) . '=' . trim($value));
            }
        }
    }
    
    private function validateEnv() {
        $required = ['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS'];
        foreach ($required as $var) {
            if (empty(getenv($var))) {
                throw new RuntimeException("Missing required environment variable: $var");
            }
        }
    }
    
    public static function connect() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->pdo;
    }
    
    // Prevent cloning and unserializing
    private function __clone() {}
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}