<?php
// Validate and sanitize input
$name = trim($_POST['name']);
$description = trim($_POST['description']);
$category_id = intval($_POST['category_id']);
$price = floatval($_POST['price']);
$stock_quantity = intval($_POST['stock_quantity']);
$environment_suitability = trim($_POST['environment_suitability']);
$care_instructions = trim($_POST['care_instructions']);
$is_featured = isset($_POST['is_featured']) ? 1 : 0;

// Basic validation
if (empty($name) || empty($description) || $price <= 0 || $stock_quantity < 0) {
    $_SESSION['error'] = "Please fill all required fields with valid data";
    header('Location: products.php');
    exit;
}

// Insert product into database
$insert_query = "INSERT INTO Products (name, description, category_id, price, stock_quantity, 
                 environment_suitability, care_instructions, is_featured) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($insert_query);
$stmt->bind_param("ssidsssi", $name, $description, $category_id, $price, $stock_quantity, 
                 $environment_suitability, $care_instructions, $is_featured);

if ($stmt->execute()) {
    $product_id = $stmt->insert_id;
    
    // Handle file uploads
    if (!empty($_FILES['product_images']['name'][0])) {
        $upload_dir = '../uploads/products/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $primary_set = false;
        foreach ($_FILES['product_images']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['product_images']['name'][$key];
            $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            $new_name = uniqid('product_', true) . '.' . $file_ext;
            $upload_path = $upload_dir . $new_name;
            
            if (move_uploaded_file($tmp_name, $upload_path)) {
                // Insert image record
                $is_primary = !$primary_set ? 1 : 0;
                $primary_set = true;
                
                $image_query = "INSERT INTO ProductImages (product_id, image_url, is_primary) VALUES (?, ?, ?)";
                $img_stmt = $conn->prepare($image_query);
                $img_stmt->bind_param("isi", $product_id, $new_name, $is_primary);
                $img_stmt->execute();
            }
        }
    }
    
    $_SESSION['message'] = "Product added successfully";
} else {
    $_SESSION['error'] = "Error adding product: " . $conn->error;
}

header('Location: products.php');
exit;
?>