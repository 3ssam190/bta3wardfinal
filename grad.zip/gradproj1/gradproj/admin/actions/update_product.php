<?php
// Validate and sanitize input
$product_id = intval($_POST['product_id']);
$name = trim($_POST['name']);
$description = trim($_POST['description']);
$category_id = intval($_POST['category_id']);
$price = floatval($_POST['price']);
$stock_quantity = intval($_POST['stock_quantity']);
$environment_suitability = trim($_POST['environment_suitability']);
$care_instructions = trim($_POST['care_instructions']);
$is_featured = isset($_POST['is_featured']) ? 1 : 0;

// Basic validation
if (empty($name) || empty($description) || $price <= 0 || $stock_quantity < 0) {
    $_SESSION['error'] = "Please fill all required fields with valid data";
    header('Location: products.php');
    exit;
}

// Update product in database
$update_query = "UPDATE Products SET 
                name = ?, 
                description = ?, 
                category_id = ?, 
                price = ?, 
                stock_quantity = ?, 
                environment_suitability = ?, 
                care_instructions = ?, 
                is_featured = ?,
                updated_at = CURRENT_TIMESTAMP
                WHERE product_id = ?";
$stmt = $conn->prepare($update_query);
$stmt->bind_param("ssidsssii", $name, $description, $category_id, $price, $stock_quantity, 
                 $environment_suitability, $care_instructions, $is_featured, $product_id);

if ($stmt->execute()) {
    $_SESSION['message'] = "Product updated successfully";
} else {
    $_SESSION['error'] = "Error updating product: " . $conn->error;
}

header('Location: products.php');
exit;
?>