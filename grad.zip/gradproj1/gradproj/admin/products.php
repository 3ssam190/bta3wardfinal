<?php
// Start session and check admin authentication
session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Include database connection
require_once __DIR__ . '/./config/Database.php';
$pdo = Database::connect();
$stmt = $pdo->prepare("SELECT * FROM Products");
$stmt->execute();
$products = $stmt->fetchAll();

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        require_once 'actions/add_product.php';
    } elseif (isset($_POST['update_product'])) {
        require_once 'actions/update_product.php';
    }
}

// Handle product deletion
if (isset($_GET['delete'])) {
    $product_id = intval($_GET['delete']);
    $delete_query = "DELETE FROM Products WHERE product_id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    
    $_SESSION['message'] = "Product deleted successfully";
    header('Location: products.php');
    exit;
}

// Fetch all products with categories
$products_query = "SELECT p.*, c.name AS category_name 
                   FROM Products p 
                   JOIN Categories c ON p.category_id = c.category_id
                   ORDER BY p.created_at DESC";
$products_result = $conn->query($products_query);

// Fetch all categories for dropdown
$categories_query = "SELECT * FROM Categories ORDER BY name";
$categories_result = $conn->query($categories_query);
?>

    <?php include 'header.php'; ?>
    <?php include 'topbar.php'; ?>
    <?php include 'sidebar.php'; ?>

    <main class="md:ml-64 pt-16 p-6">
        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['message'])): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?= $_SESSION['message'] ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </span>
        </div>
        <?php unset($_SESSION['message']); endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <span class="block sm:inline"><?= $_SESSION['error'] ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3" onclick="this.parentElement.remove()">
                <i class="fas fa-times"></i>
            </span>
        </div>
        <?php unset($_SESSION['error']); endif; ?>

        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-semibold text-gray-800">Products Management</h2>
            <button onclick="openAddProductModal()" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center">
                <i class="fas fa-plus mr-2"></i> Add Product
            </button>
        </div>

        <!-- Products Table -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Featured</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php while ($product = $products_result->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= htmlspecialchars($product['product_id']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <?php 
                                        // Get primary image for product
                                        $image_query = "SELECT image_url FROM ProductImages WHERE product_id = ? AND is_primary = 1 LIMIT 1";
                                        $stmt = $conn->prepare($image_query);
                                        $stmt->bind_param("i", $product['product_id']);
                                        $stmt->execute();
                                        $image_result = $stmt->get_result();
                                        $image = $image_result->fetch_assoc();
                                        ?>
                                        <img class="h-10 w-10 rounded-full object-cover" src="<?= $image ? '../uploads/' . htmlspecialchars($image['image_url']) : '../assets/images/default-product.png' ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($product['name']) ?></div>
                                        <div class="text-sm text-gray-500"><?= substr(htmlspecialchars($product['description']), 0, 30) ?>...</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= htmlspecialchars($product['category_name']) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">EGP <?= number_format($product['price'], 2) ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?= $product['stock_quantity'] ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?= $product['is_featured'] ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800' ?>">
                                    <?= $product['is_featured'] ? 'Yes' : 'No' ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button onclick="openEditProductModal(
                                    <?= $product['product_id'] ?>,
                                    '<?= htmlspecialchars($product['name'], ENT_QUOTES) ?>',
                                    '<?= htmlspecialchars($product['description'], ENT_QUOTES) ?>',
                                    <?= $product['category_id'] ?>,
                                    <?= $product['price'] ?>,
                                    <?= $product['stock_quantity'] ?>,
                                    '<?= htmlspecialchars($product['environment_suitability'], ENT_QUOTES) ?>',
                                    '<?= htmlspecialchars($product['care_instructions'], ENT_QUOTES) ?>',
                                    <?= $product['is_featured'] ? 'true' : 'false' ?>
                                )" class="text-indigo-600 hover:text-indigo-900 mr-3">
                                    <i class="fas fa-edit"></i> Edit
                                </button>
                                <a href="products.php?delete=<?= $product['product_id'] ?>" class="text-red-600 hover:text-red-900" onclick="return confirm('Are you sure you want to delete this product?');">
                                    <i class="fas fa-trash"></i> Delete
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Add Product Modal -->
        <div id="addProductModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
            <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 transition-opacity" aria-hidden="true">
                    <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
                </div>
                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <form method="POST" action="products.php" enctype="multipart/form-data">
                        <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                            <div class="sm:flex sm:items-start">
                                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Add New Product</h3>
                                    <div class="grid grid-cols-1 gap-y-4 gap-x-6 sm:grid-cols-6">
                                        <div class="sm:col-span-6">
                                            <label for="name" class="block text-sm font-medium text-gray-700">Product Name</label>
                                            <input type="text" name="name" id="name" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-6">
                                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                                            <textarea name="description" id="description" rows="3" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="category_id" class="block text-sm font-medium text-gray-700">Category</label>
                                            <select name="category_id" id="category_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm">
                                                <?php while ($category = $categories_result->fetch_assoc()): ?>
                                                <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="price" class="block text-sm font-medium text-gray-700">Price (EGP)</label>
                                            <input type="number" step="0.01" name="price" id="price" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="stock_quantity" class="block text-sm font-medium text-gray-700">Stock Quantity</label>
                                            <input type="number" name="stock_quantity" id="stock_quantity" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="environment_suitability" class="block text-sm font-medium text-gray-700">Environment</label>
                                            <input type="text" name="environment_suitability" id="environment_suitability" class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" placeholder="Indoor, Outdoor, etc.">
                                        </div>
                                        <div class="sm:col-span-6">
                                            <label for="care_instructions" class="block text-sm font-medium text-gray-700">Care Instructions</label>
                                            <textarea name="care_instructions" id="care_instructions" rows="2" class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                        </div>
                                        <div class="sm:col-span-6">
                                            <div class="flex items-center">
                                                <input type="checkbox" name="is_featured" id="is_featured" class="focus:ring-green-500 h-4 w-4 text-green-600 border-gray-300 rounded">
                                                <label for="is_featured" class="ml-2 block text-sm text-gray-700">Featured Product</label>
                                            </div>
                                        </div>
                                        <div class="sm:col-span-6">
                                            <label class="block text-sm font-medium text-gray-700">Product Images</label>
                                            <div class="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                                                <div class="space-y-1 text-center">
                                                    <div class="flex text-sm text-gray-600">
                                                        <label for="product_images" class="relative cursor-pointer bg-white rounded-md font-medium text-green-600 hover:text-green-500 focus-within:outline-none">
                                                            <span>Upload files</span>
                                                            <input id="product_images" name="product_images[]" type="file" multiple class="sr-only">
                                                        </label>
                                                        <p class="pl-1">or drag and drop</p>
                                                    </div>
                                                    <p class="text-xs text-gray-500">PNG, JPG, GIF up to 10MB</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit" name="add_product" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                                Add Product
                            </button>
                            <button type="button" onclick="closeAddProductModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Edit Product Modal -->
        <div id="editProductModal" class="fixed z-10 inset-0 overflow-y-auto hidden">
            <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 transition-opacity" aria-hidden="true">
                    <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
                </div>
                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
                <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <form method="POST" action="products.php">
                        <input type="hidden" name="product_id" id="edit_product_id">
                        <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                            <div class="sm:flex sm:items-start">
                                <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Edit Product</h3>
                                    <div class="grid grid-cols-1 gap-y-4 gap-x-6 sm:grid-cols-6">
                                        <div class="sm:col-span-6">
                                            <label for="edit_name" class="block text-sm font-medium text-gray-700">Product Name</label>
                                            <input type="text" name="name" id="edit_name" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-6">
                                            <label for="edit_description" class="block text-sm font-medium text-gray-700">Description</label>
                                            <textarea name="description" id="edit_description" rows="3" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="edit_category_id" class="block text-sm font-medium text-gray-700">Category</label>
                                            <select name="category_id" id="edit_category_id" required class="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm">
                                                <?php 
                                                // Reset pointer for categories result
                                                $categories_result->data_seek(0);
                                                while ($category = $categories_result->fetch_assoc()): ?>
                                                <option value="<?= $category['category_id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                                <?php endwhile; ?>
                                            </select>
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="edit_price" class="block text-sm font-medium text-gray-700">Price (EGP)</label>
                                            <input type="number" step="0.01" name="price" id="edit_price" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="edit_stock_quantity" class="block text-sm font-medium text-gray-700">Stock Quantity</label>
                                            <input type="number" name="stock_quantity" id="edit_stock_quantity" required class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md">
                                        </div>
                                        <div class="sm:col-span-3">
                                            <label for="edit_environment_suitability" class="block text-sm font-medium text-gray-700">Environment</label>
                                            <input type="text" name="environment_suitability" id="edit_environment_suitability" class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" placeholder="Indoor, Outdoor, etc.">
                                        </div>
                                        <div class="sm:col-span-6">
                                            <label for="edit_care_instructions" class="block text-sm font-medium text-gray-700">Care Instructions</label>
                                            <textarea name="care_instructions" id="edit_care_instructions" rows="2" class="mt-1 focus:ring-green-500 focus:border-green-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"></textarea>
                                        </div>
                                        <div class="sm:col-span-6">
                                            <div class="flex items-center">
                                                <input type="checkbox" name="is_featured" id="edit_is_featured" class="focus:ring-green-500 h-4 w-4 text-green-600 border-gray-300 rounded">
                                                <label for="edit_is_featured" class="ml-2 block text-sm text-gray-700">Featured Product</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit" name="update_product" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm">
                                Update Product
                            </button>
                            <button type="button" onclick="closeEditProductModal()" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        // Modal functions
        function openAddProductModal() {
            document.getElementById('addProductModal').classList.remove('hidden');
        }

        function closeAddProductModal() {
            document.getElementById('addProductModal').classList.add('hidden');
        }

        function openEditProductModal(id, name, description, categoryId, price, stock, environment, careInstructions, isFeatured) {
            document.getElementById('edit_product_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_description').value = description;
            document.getElementById('edit_category_id').value = categoryId;
            document.getElementById('edit_price').value = price;
            document.getElementById('edit_stock_quantity').value = stock;
            document.getElementById('edit_environment_suitability').value = environment;
            document.getElementById('edit_care_instructions').value = careInstructions;
            document.getElementById('edit_is_featured').checked = isFeatured;
            
            document.getElementById('editProductModal').classList.remove('hidden');
        }

        function closeEditProductModal() {
            document.getElementById('editProductModal').classList.add('hidden');
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target === document.getElementById('addProductModal')) {
                closeAddProductModal();
            }
            if (event.target === document.getElementById('editProductModal')) {
                closeEditProductModal();
            }
        }
    </script>