<!-- Top navbar -->
<header class="bg-white shadow-sm fixed top-0 right-0 left-0 md:left-64 z-30 h-16 transition-all duration-300 ease-in-out">
    <div class="flex items-center justify-between px-6 py-3">
        <!-- Mobile menu button -->
        <button 
            @click="sidebarOpen = !sidebarOpen" 
            class="md:hidden text-gray-500 hover:text-gray-600 focus:outline-none"
        >
            <i class="fas fa-bars" x-show="!sidebarOpen"></i>
            <i class="fas fa-times" x-show="sidebarOpen" style="display: none"></i>
        </button>
        
        <div class="relative">
            <button id="profileBtn" class="flex items-center gap-2 bg-green-600 text-white px-3 py-2 rounded hover:bg-green-500">
                Profile ▼
            </button>
            <div id="profileMenu" class="absolute right-0 mt-2 w-40 bg-white text-gray-800 rounded shadow-lg hidden">
                <a href="settings.php" class="block px-4 py-2 hover:bg-green-100">Settings</a>
                <a href="logout.php" class="block px-4 py-2 hover:bg-green-100">Logout</a>
            </div>
        </div>
            
    </div>
    
    
</header>
