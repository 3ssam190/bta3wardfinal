<aside id="sidebar" class="fixed top-0 left-0 z-40 h-full bg-green-700 text-white transition-all duration-300 ease-in-out w-64 md:block overflow-hidden" style="top: 4rem; height: calc(100vh - 4rem);">
  <div class="h-full flex flex-col pt-20 space-y-2">
  <button id="desktopSidebarToggle" class="hidden md:inline-flex items-center text-white hover:text-gray-300 mr-4 px-4">
  <i class="fas fa-bars text-xl"></i>
</button>
  <a href="dashboard.php" class="flex items-center gap-3 p-2 rounded hover:bg-green-600 transition-all">
            <i class="fas fa-home text-lg w-6 text-center"></i>
            <span class="sidebar-text">Dashboard</span>
        </a>
        <a href="orders.php" class="flex items-center gap-3 p-2 rounded hover:bg-green-600 transition-all">
            <i class="fas fa-box text-lg w-6 text-center"></i>
            <span class="sidebar-text">Orders</span>
        </a>
        <a href="products.php" class="flex items-center gap-3 p-2 rounded hover:bg-green-600 transition-all">
            <i class="fas fa-box text-lg w-6 text-center"></i>
            <span class="sidebar-text">Products</span>
        </a>
        <a href="users.php" class="flex items-center gap-3 p-2 rounded hover:bg-green-600 transition-all">
            <i class="fas fa-box text-lg w-6 text-center"></i>
            <span class="sidebar-text">Users</span>
        </a>
        <a href="settings.php" class="flex items-center gap-3 p-2 rounded hover:bg-green-600 transition-all">
            <i class="fas fa-box text-lg w-6 text-center"></i>
            <span class="sidebar-text">Settings</span>
        </a>
  </div>
</aside>


<!-- Mobile toggle button -->
<button id="toggleSidebar" class="hidden md:inline-block text-gray-700 hover:text-green-700 mr-4">
    <i class="fas fa-bars text-xl"></i>
</button>
