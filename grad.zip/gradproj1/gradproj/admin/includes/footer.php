<!-- Alpine JS -->
<script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

<!-- Custom JS -->
<script>
// Notification function
function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `fixed top-4 right-4 z-50 px-6 py-4 rounded-lg shadow-lg flex items-start max-w-md transform transition-all duration-300 translate-x-48 opacity-0 ${
        type === 'success' ? 'bg-green-50 text-green-800' : 
        type === 'error' ? 'bg-red-50 text-red-800' : 
        'bg-blue-50 text-blue-800'
    }`;
    
    const icon = document.createElement('div');
    icon.className = `mr-3 mt-0.5 flex-shrink-0 ${
        type === 'success' ? 'text-green-500' : 
        type === 'error' ? 'text-red-500' : 
        'text-blue-500'
    }`;
    
    icon.innerHTML = type === 'success' ? 
        '<i class="fas fa-check-circle"></i>' : 
        type === 'error' ? '<i class="fas fa-exclamation-circle"></i>' : 
        '<i class="fas fa-info-circle"></i>';
    
    const content = document.createElement('div');
    content.className = 'flex-1';
    content.innerHTML = `<p class="text-sm font-medium">${message}</p>`;
    
    const close = document.createElement('button');
    close.className = 'ml-4 -mr-2 p-1 rounded-full focus:outline-none hover:bg-opacity-20 hover:bg-current transition duration-150';
    close.innerHTML = '<i class="fas fa-times"></i>';
    close.addEventListener('click', () => {
        notification.classList.add('opacity-0', 'translate-x-48');
        setTimeout(() => notification.remove(), 300);
    });
    
    notification.appendChild(icon);
    notification.appendChild(content);
    notification.appendChild(close);
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.remove('translate-x-48', 'opacity-0');
        notification.classList.add('translate-x-0', 'opacity-100');
    }, 10);
    
    setTimeout(() => {
        notification.classList.add('opacity-0', 'translate-x-48');
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// Check for notification in URL
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const notification = urlParams.get('notification');
    const notificationType = urlParams.get('notification_type');
    
    if (notification && notificationType) {
        showNotification(notificationType, decodeURIComponent(notification));
        
        // Clean URL
        const cleanUrl = window.location.origin + window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
    }
});
</script>
<script>
// Handle sidebar state persistence
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Alpine.js
    Alpine.data('main', () => ({
        sidebarOpen: window.innerWidth >= 768,
        
        init() {
            // Load saved state from localStorage
            const savedState = localStorage.getItem('sidebarState');
            if (savedState) {
                this.sidebarOpen = savedState === 'open';
            }
            
            // Update on resize
            window.addEventListener('resize', () => {
                if (window.innerWidth >= 768) {
                    this.sidebarOpen = true;
                }
            });
        },
        
        toggleSidebar() {
            this.sidebarOpen = !this.sidebarOpen;
            localStorage.setItem('sidebarState', this.sidebarOpen ? 'open' : 'closed');
        }
    }));

    // Close sidebar when clicking on mobile menu items
    document.querySelectorAll('.mobile-menu-item').forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth < 768) {
                Alpine.store('sidebarOpen', false);
            }
        });
    });
});
</script>

</body>
</html>