<?php
// Start session and check authentication if needed
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: /admin/login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PlantsStore Admin</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/adminstyle.css">
    <!-- Custom CSS -->
    <style>
        [x-cloak] { display: none !important; }
        .sidebar-transition {
            transition: all 0.3s ease-in-out;
        }
        .dropdown-enter {
            opacity: 0;
            transform: translateY(-10px);
        }
        .dropdown-enter-active {
            opacity: 1;
            transform: translateY(0);
            transition: all 0.2s ease-out;
        }
        .dropdown-leave {
            opacity: 1;
            transform: translateY(0);
        }
        .dropdown-leave-active {
            opacity: 0;
            transform: translateY(-10px);
            transition: all 0.2s ease-in;
        }
    </style>
    <script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Alpine.js data
    window.alpineData = {
        sidebarOpen: window.innerWidth >= 768
    };
});
</script>
</head>
<body class="bg-green-50 min-h-screen flex flex-col md:flex-row">
