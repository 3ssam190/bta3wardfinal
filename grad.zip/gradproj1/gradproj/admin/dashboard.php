<?php 
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
require_once __DIR__ . '/includes/topbar.php';
?>

<!-- Main content -->
<main id="mainContent" class="transition-all duration-300 ease-in-out md:ml-64 pt-20 p-6 bg-green-50 min-h-screen">

  <h2 class="text-3xl font-semibold text-green-800 mb-6">Dashboard Overview</h2>
  
  <!-- Cards -->
  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    <div class="bg-white shadow-lg rounded-2xl p-4 border-l-4 border-green-500">
      <h3 class="text-lg font-semibold text-green-700">Total Products</h3>
      <p class="text-2xl font-bold text-gray-800">123</p>
    </div>
    <div class="bg-white shadow-lg rounded-2xl p-4 border-l-4 border-green-500">
      <h3 class="text-lg font-semibold text-green-700">Orders</h3>
      <p class="text-2xl font-bold text-gray-800">45</p>
    </div>
    <div class="bg-white shadow-lg rounded-2xl p-4 border-l-4 border-green-500">
      <h3 class="text-lg font-semibold text-green-700">Users</h3>
      <p class="text-2xl font-bold text-gray-800">89</p>
    </div>
  </div>

  <!-- Recent Orders -->
  <div class="mt-10">
    <h3 class="text-xl font-semibold text-green-800 mb-4">Recent Orders</h3>
    <div class="overflow-x-auto">
      <table class="w-full text-left bg-white rounded-2xl shadow-md">
        <thead class="bg-green-100 text-green-900">
          <tr>
            <th class="p-3">Order ID</th>
            <th class="p-3">Customer</th>
            <th class="p-3">Amount</th>
            <th class="p-3">Status</th>
          </tr>
        </thead>
        <tbody class="text-gray-700 divide-y divide-green-100">
          <tr>
            <td class="p-3">#00123</td>
            <td class="p-3">Alice</td>
            <td class="p-3">$120</td>
            <td class="p-3 text-green-600">Shipped</td>
          </tr>
          <tr>
            <td class="p-3">#00122</td>
            <td class="p-3">Bob</td>
            <td class="p-3">$85</td>
            <td class="p-3 text-yellow-500">Pending</td>
          </tr>
          <tr>
            <td class="p-3">#00121</td>
            <td class="p-3">Charlie</td>
            <td class="p-3">$50</td>
            <td class="p-3 text-red-500">Cancelled</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</main>

<!-- Scripts -->
<script>
  const menuToggle = document.getElementById('menuToggle');
  const desktopToggle = document.getElementById('desktopSidebarToggle');
  const sidebar = document.getElementById('sidebar');
  const mainContent = document.getElementById('mainContent');
  const profileBtn = document.getElementById('profileBtn');
  const profileMenu = document.getElementById('profileMenu');
  

  // Mobile sidebar toggle
  menuToggle?.addEventListener('click', () => {
    sidebar.classList.toggle('-translate-x-full');
  });

  desktopToggle?.addEventListener('click', () => {
  sidebar.classList.toggle('w-64');
  sidebar.classList.toggle('w-16');

  // Hide/show text in sidebar
  document.querySelectorAll('.sidebar-text').forEach(span => {
    span.classList.toggle('hidden');
  });

  // Adjust main content margin
  mainContent.classList.toggle('md:ml-64');
  mainContent.classList.toggle('md:ml-16');
});

  // Profile menu toggle
  profileBtn?.addEventListener('click', () => {
    profileMenu.classList.toggle('hidden');
  });

  // Click outside to close profile menu
  document.addEventListener('click', (e) => {
    if (!profileBtn.contains(e.target) && !profileMenu.contains(e.target)) {
      profileMenu.classList.add('hidden');
    }
  });
</script>

<?php 
require_once __DIR__ . '/includes/footer.php';
?>
