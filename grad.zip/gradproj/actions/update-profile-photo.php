<?php
require_once __DIR__ . '/../config.php';

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check for either user or admin login
if (!isset($_SESSION['user_id']) && !isset($_SESSION['admin_id'])) {
    header("Location: " . BASE_URL . "/pages/signin.php");
    exit();
}

// Determine user type and ID
$userType = isset($_SESSION['user_id']) ? 'user' : 'admin';
$userId = $_SESSION[$userType.'_id'];

// Set upload directory and allowed file types
$uploadDir = $_SERVER['DOCUMENT_ROOT'] . '/grad/gradproj/assets/images/profile_photos/';
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
$maxFileSize = 2 * 1024 * 1024; // 2MB

// Create upload directory if it doesn't exist
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Process file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_photo'])) {
    $file = $_FILES['profile_photo'];
    
    // Validate file
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['error'] = "File upload error: " . $file['error'];
        header("Location: " . BASE_URL . "/pages/profile.php");
        exit();
    }
    
    if (!in_array($file['type'], $allowedTypes)) {
        $_SESSION['error'] = "Only JPG, PNG, and GIF files are allowed.";
        header("Location: " . BASE_URL . "/pages/profile.php");
        exit();
    }
    
    if ($file['size'] > $maxFileSize) {
        $_SESSION['error'] = "File size must be less than 2MB.";
        header("Location: " . BASE_URL . "/pages/profile.php");
        exit();
    }
    
    // Generate unique filename
    $fileExt = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = $userType . '_' . $userId . '_' . time() . '.' . $fileExt;
    $filePath = $uploadDir . $fileName;
    
    // Move uploaded file
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        // Relative path to store in database (consistent with your current format)
        $relativePath = '/assets/images/profile_photos/' . $fileName;
        
        try {
            // Update database
            if ($userType === 'user') {
                $stmt = $conn->prepare("UPDATE Users SET profile_photo = ? WHERE user_id = ?");
            } else {
                $stmt = $conn->prepare("UPDATE Admins SET admin_photo = ? WHERE admin_id = ?");
            }
            $stmt->execute([$relativePath, $userId]);
            
            // Update session and refresh user data
            $_SESSION['profile_photo'] = $relativePath;
            $_SESSION['success'] = "Profile photo updated successfully!";
            
            // Fetch updated user data
            if ($userType === 'user') {
                $userStmt = $conn->prepare("SELECT *, profile_photo FROM Users WHERE user_id = ?");
            } else {
                $userStmt = $conn->prepare("SELECT *, admin_photo AS profile_photo FROM Admins WHERE admin_id = ?");
            }
            $userStmt->execute([$userId]);
            $_SESSION['updated_user_data'] = $userStmt->fetch(PDO::FETCH_ASSOC);
            
            // Delete old photo if it exists and isn't a default image
            if (!empty($_POST['current_photo_path']) && 
                strpos($_POST['current_photo_path'], 'default-') === false) {
                $oldPhotoPath = $_SERVER['DOCUMENT_ROOT'] . parse_url($_POST['current_photo_path'], PHP_URL_PATH);
                if (file_exists($oldPhotoPath)) {
                    unlink($oldPhotoPath);
                }
            }
            
        } catch (PDOException $e) {
            // Delete the uploaded file if database update fails
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            $_SESSION['error'] = "Database error: " . $e->getMessage();
        }
    } else {
        $_SESSION['error'] = "Failed to upload file.";
    }
    
    header("Location: " . BASE_URL . "/pages/profile.php");
    exit();
}

// If not a POST request with file, redirect to profile
header("Location: " . BASE_URL . "/pages/profile.php");
exit();
?>