<?php
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/topbar.php';
require_once __DIR__ . '/config/database.php';

// Initialize database connection
try {
    $pdo = Database::connect();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Handle status update
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE Orders SET status = ? WHERE order_id = ?");
        $stmt->execute([$new_status, $order_id]);
        
        $_SESSION['message'] = "Order status updated successfully";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error updating order status: " . $e->getMessage();
    }
    
    header('Location: orders.php');
    exit;
}

// Pagination setup
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

// Get filter parameters
$status_filter = $_GET['status'] ?? '';
$search_query = $_GET['search'] ?? '';

// Build base query and count query
$query = "
    SELECT 
        o.order_id,
        o.order_date,
        o.total_amount,
        o.delivery_fee,
        o.status,
        CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
        u.email AS customer_email,
        (SELECT COUNT(*) FROM OrderItems WHERE order_id = o.order_id) AS item_count
    FROM Orders o
    JOIN Users u ON o.user_id = u.user_id
";

$count_query = "SELECT COUNT(*) FROM Orders o";

// Add filters if specified
$where_clauses = [];
$params = [];
$count_params = [];

if ($status_filter) {
    $where_clauses[] = "o.status = ?";
    $params[] = $status_filter;
    $count_params[] = $status_filter;
}

if ($search_query) {
    $where_clauses[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR o.order_id = ?)";
    $search_param = "%$search_query%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_query;
    $count_params[] = $search_param;
    $count_params[] = $search_param;
    $count_params[] = $search_param;
    $count_params[] = $search_query;
}

// Complete the queries
if (!empty($where_clauses)) {
    $query .= " WHERE " . implode(" AND ", $where_clauses);
    $count_query .= " WHERE " . implode(" AND ", $where_clauses);
}

$query .= " ORDER BY o.order_date DESC LIMIT :limit OFFSET :offset";

// Get total number of orders
$stmt = $pdo->prepare($count_query);
$stmt->execute($count_params);
$totalOrders = $stmt->fetchColumn();
$totalPages = ceil($totalOrders / $perPage);

// Get orders
$stmt = $pdo->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key + 1, $value);
}
$stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Status options for filter and update
$status_options = [
    'Pending' => 'Pending',
    'Confirmed' => 'Confirmed',
    'Processing' => 'Processing',
    'Shipped' => 'Shipped',
    'Delivered' => 'Delivered',
    'Cancelled' => 'Cancelled'
];
?>

<!-- Main Content -->
<main class="container-fluid py-4" style="margin-top: 70px;">
    <!-- Success/Error Messages -->
    <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['message']); endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); endif; ?>

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-3 mb-md-0 text-primary">Orders Management</h2>
        <div class="d-flex gap-2">
            <!-- Status Filter -->
            <form method="GET" class="d-flex gap-2">
                <select class="form-select" name="status" onchange="this.form.submit()">
                    <option value="">All Statuses</option>
                    <?php foreach ($status_options as $value => $label): ?>
                        <option value="<?= $value ?>" <?= $status_filter === $value ? 'selected' : '' ?>>
                            <?= $label ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <!-- Search Box -->
                <div class="input-group">
                    <input type="text" class="form-control" name="search" placeholder="Search orders..." 
                           value="<?= htmlspecialchars($search_query) ?>">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                    <?php if ($status_filter || $search_query): ?>
                        <a href="orders.php" class="btn btn-outline-secondary">
                            <i class="fas fa-times"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <!-- Orders Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-primary">
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Date</th>
                            <th>Items</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr>
                            <td>#<?= str_pad($order['order_id'], 5, '0', STR_PAD_LEFT) ?></td>
                            <td>
                                <div class="d-flex flex-column">
                                    <span class="fw-bold"><?= htmlspecialchars($order['customer_name']) ?></span>
                                    <span class="small text-muted"><?= htmlspecialchars($order['customer_email']) ?></span>
                                </div>
                            </td>
                            <td><?= date('M j, Y g:i A', strtotime($order['order_date'])) ?></td>
                            <td><?= $order['item_count'] ?></td>
                            <td>EGP <?= number_format($order['total_amount'] + $order['delivery_fee'], 2) ?></td>
                            <td>
                                <span class="badge <?= 
                                    $order['status'] === 'Pending' ? 'bg-warning text-dark' : 
                                    ($order['status'] === 'Confirmed' ? 'bg-info' : 
                                    ($order['status'] === 'Processing' ? 'bg-primary' : 
                                    ($order['status'] === 'Shipped' ? 'bg-secondary' : 
                                    ($order['status'] === 'Delivered' ? 'bg-success' : 'bg-danger')))) ?>">
                                    <?= $order['status'] ?>
                                </span>
                            </td>
                            <td>
                                <button onclick="viewOrderDetails(<?= $order['order_id'] ?>)" 
                                        class="btn btn-sm btn-outline-primary me-2">
                                    <i class="fas fa-eye me-1"></i> View
                                </button>
                                
                                <div class="dropdown d-inline-block">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" 
                                            type="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-cog me-1"></i> Status
                                    </button>
                                    <ul class="dropdown-menu">
                                        <?php foreach ($status_options as $value => $label): ?>
                                            <?php if ($value !== $order['status']): ?>
                                                <li>
                                                    <form method="POST" class="dropdown-item p-0">
                                                        <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                                        <input type="hidden" name="status" value="<?= $value ?>">
                                                        <button type="submit" name="update_status" 
                                                                class="btn btn-link text-decoration-none w-100 text-start">
                                                            <?= $label ?>
                                                        </button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <nav class="d-flex justify-content-between align-items-center mt-4">
                <div>
                    <p class="small text-muted mb-0">
                        Showing <span class="fw-bold"><?= $offset + 1 ?></span> to 
                        <span class="fw-bold"><?= min($offset + $perPage, $totalOrders) ?></span> of 
                        <span class="fw-bold"><?= $totalOrders ?></span> results
                    </p>
                </div>
                <ul class="pagination mb-0">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="orders.php?page=<?= $page - 1 ?><?= $status_filter ? '&status=' . urlencode($status_filter) : '' ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="orders.php?page=<?= $i ?><?= $status_filter ? '&status=' . urlencode($status_filter) : '' ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="orders.php?page=<?= $page + 1 ?><?= $status_filter ? '&status=' . urlencode($status_filter) : '' ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>

    <!-- Order Details Modal -->
    <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Order Details</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="orderDetailsContent">
                    <!-- Content will be loaded dynamically via JavaScript -->
                    <div class="text-center py-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="printOrderDetails()">
                        <i class="fas fa-print me-1"></i> Print
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
// Make order-related functions available globally
window.viewOrderDetails = async function(orderId) {
    try {
        const response = await fetch(`actions/get_order_details.php?id=${orderId}`);
        if (!response.ok) throw new Error('Network error');
        
        const data = await response.json();
        if (!data.success) throw new Error(data.error || 'Failed to load order details');
        
        populateOrderDetailsModal(data);
        
        const modal = new bootstrap.Modal(document.getElementById('orderDetailsModal'));
        modal.show();
        
    } catch (error) {
        console.error('Error:', error);
        showNotification('error', `Failed to load order details: ${error.message}`);
    }
};

window.printOrderDetails = function() {
    const printContent = document.getElementById('orderDetailsContent').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = `
        <div class="container mt-4">
            <h2 class="mb-4">Order Details - PlantsStore</h2>
            ${printContent}
            <div class="text-muted small mt-4">Printed on ${new Date().toLocaleString()}</div>
        </div>
    `;
    
    window.print();
    document.body.innerHTML = originalContent;
    
    // Reinitialize any necessary event listeners
    if (typeof initDarkMode === 'function') {
        initDarkMode();
    }
};

// Function to populate order details modal
function populateOrderDetailsModal(data) {
    const order = data.order;
    const items = data.items;
    const payment = data.payment;
    
    // Format date
    const orderDate = new Date(order.order_date);
    const formattedDate = orderDate.toLocaleDateString('en-US', {
        year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
    
    // Create the order details content
    const content = `
        <div class="row">
            <!-- Order Summary -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">Order Information</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <p class="small text-muted mb-1">Order Number</p>
                            <p class="fw-bold">#${order.order_id.toString().padStart(5, '0')}</p>
                        </div>
                        
                        <div class="mb-3">
                            <p class="small text-muted mb-1">Order Date</p>
                            <p class="fw-bold">${formattedDate}</p>
                        </div>
                        
                        <div class="mb-3">
                            <p class="small text-muted mb-1">Status</p>
                            <p>
                                <span class="badge ${getStatusBadgeClass(order.status)}">
                                    ${order.status}
                                </span>
                            </p>
                        </div>
                        
                        <div class="mb-3">
                            <p class="small text-muted mb-1">Customer</p>
                            <p class="fw-bold">${escapeHtml(order.customer_name)}</p>
                            <p class="small">${escapeHtml(order.customer_email)}</p>
                        </div>
                    </div>
                </div>
                
                <!-- Delivery Information -->
                <div class="card">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">Delivery Information</h6>
                    </div>
                    <div class="card-body">
                        <p class="fw-bold">${escapeHtml(order.delivery_address)}</p>
                        <p>
                            ${escapeHtml(order.delivery_city)}, 
                            ${escapeHtml(order.delivery_region)}
                        </p>
                        ${order.notes ? `<div class="mt-3">
                            <p class="small text-muted mb-1">Customer Notes</p>
                            <p>${escapeHtml(order.notes)}</p>
                        </div>` : ''}
                    </div>
                </div>
            </div>
            
            <!-- Order Items -->
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">Order Items (${items.length})</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Qty</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${items.map(item => `
                                        <tr>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <img src="assets/images/products/${escapeHtml(item.image_url || 'default-product.jpg')}" 
                                                         class="rounded-circle me-2" width="40" height="40" 
                                                         onerror="this.src='assets/images/default-product.jpg'">
                                                    <div>
                                                        <div class="fw-bold">${escapeHtml(item.product_name)}</div>
                                                        <div class="small text-muted">SKU: ${item.product_id}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>${item.quantity}</td>
                                            <td>EGP ${item.unit_price.toFixed(2)}</td>
                                            <td>EGP ${(item.quantity * item.unit_price).toFixed(2)}</td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Payment Summary -->
                <div class="card">
                    <div class="card-header bg-light">
                        <h6 class="mb-0">Payment Summary</h6>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <span>EGP ${order.total_amount.toFixed(2)}</span>
                        </div>
                        
                        <div class="d-flex justify-content-between mb-2">
                            <span>Delivery Fee:</span>
                            <span>EGP ${order.delivery_fee.toFixed(2)}</span>
                        </div>
                        
                        <hr class="my-2">
                        
                        <div class="d-flex justify-content-between fw-bold mb-3">
                            <span>Total:</span>
                            <span>EGP ${(order.total_amount + order.delivery_fee).toFixed(2)}</span>
                        </div>
                        
                        ${payment ? `
                            <div class="mt-3">
                                <p class="small text-muted mb-1">Payment Method</p>
                                <p class="fw-bold">${payment.payment_method}</p>
                                
                                <p class="small text-muted mb-1">Payment Status</p>
                                <p>
                                    <span class="badge ${payment.payment_status === 'Completed' ? 'bg-success' : 
                                        (payment.payment_status === 'Pending' ? 'bg-warning text-dark' : 
                                        (payment.payment_status === 'Failed' ? 'bg-danger' : 'bg-secondary'))}">
                                        ${payment.payment_status}
                                    </span>
                                </p>
                                
                                ${payment.transaction_id ? `
                                    <p class="small text-muted mb-1">Transaction ID</p>
                                    <p class="fw-bold">${escapeHtml(payment.transaction_id)}</p>
                                ` : ''}
                            </div>
                        ` : '<p class="text-muted">No payment information available</p>'}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Update the modal body
    document.getElementById('orderDetailsContent').innerHTML = content;
}

// Helper function to get badge class based on status
function getStatusBadgeClass(status) {
    switch(status) {
        case 'Pending': return 'bg-warning text-dark';
        case 'Confirmed': return 'bg-info';
        case 'Processing': return 'bg-primary';
        case 'Shipped': return 'bg-secondary';
        case 'Delivered': return 'bg-success';
        case 'Cancelled': return 'bg-danger';
        default: return 'bg-secondary';
    }
}

// Helper function to escape HTML
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
</script>

<?php 
require_once __DIR__ . '/includes/footer.php';
?>