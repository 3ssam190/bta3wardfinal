<?php
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json');

try {
    $pdo = Database::connect();
    
    // Get order ID from request
    $order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($order_id <= 0) {
        throw new Exception('Invalid order ID');
    }
    
    // Get order information
    $stmt = $pdo->prepare("
        SELECT 
            o.*,
            CONCAT(u.first_name, ' ', u.last_name) AS customer_name,
            u.email AS customer_email
        FROM Orders o
        JOIN Users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception('Order not found');
    }
    
    // Get order items
    $stmt = $pdo->prepare("
        SELECT 
            oi.*,
            p.name AS product_name,
            (SELECT image_url FROM ProductImages WHERE product_id = p.product_id AND is_primary = 1 LIMIT 1) AS image_url
        FROM OrderItems oi
        JOIN Products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get payment information
    $stmt = $pdo->prepare("
        SELECT * FROM Payments 
        WHERE order_id = ?
        ORDER BY payment_date DESC
        LIMIT 1
    ");
    $stmt->execute([$order_id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Return the data
    echo json_encode([
        'success' => true,
        'order' => $order,
        'items' => $items,
        'payment' => $payment
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>