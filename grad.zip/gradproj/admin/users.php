<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/topbar.php';
require_once __DIR__ . '/config/database.php';

// Initialize database connection
try {
    $pdo = Database::connect();
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}


if (!isset($_SESSION['admin_role']) || !isset($_SESSION['admin_id'])) {
    // Set default values if missing
    $_SESSION['admin_role'] = 'Product Manager'; // Default role
    $_SESSION['admin_id'] = 0; // Default ID
}

// Handle user actions
if (isset($_GET['delete_user'])) {
    $user_id = intval($_GET['delete_user']);
    
    try {
        $stmt = $pdo->prepare("DELETE FROM Users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        
        $_SESSION['message'] = "User deleted successfully";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
    }
    
    header('Location: users.php');
    exit;
}

if (isset($_GET['delete_admin'])) {
    $admin_id = intval($_GET['delete_admin']);
    
    try {
        // Prevent deleting the current admin
        if ($admin_id == $_SESSION['admin_id']) {
            throw new Exception("You cannot delete your own account");
        }
        
        $stmt = $pdo->prepare("DELETE FROM Admins WHERE admin_id = ?");
        $stmt->execute([$admin_id]);
        
        $_SESSION['message'] = "Admin deleted successfully";
    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
    }
    
    header('Location: users.php');
    exit;
}

// Handle status update for users
if (isset($_POST['update_user_status'])) {
    $user_id = intval($_POST['user_id']);
    $is_verified = isset($_POST['is_verified']) ? 1 : 0;
    
    try {
        $stmt = $pdo->prepare("UPDATE Users SET is_verified = ? WHERE user_id = ?");
        $stmt->execute([$is_verified, $user_id]);
        
        $_SESSION['message'] = "User status updated successfully";
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error updating user status: " . $e->getMessage();
    }
    
    header('Location: users.php');
    exit;
}

// Pagination setup
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;

// Get filter parameters
$user_type = $_GET['type'] ?? 'customers'; // 'customers' or 'admins'
$search_query = $_GET['search'] ?? '';

// Get total count
if ($user_type === 'admins') {
    $count_query = "SELECT COUNT(*) FROM Admins";
    $query = "SELECT * FROM Admins ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
} else {
    $count_query = "SELECT COUNT(*) FROM Users";
    $query = "SELECT * FROM Users ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
}

// Apply search filter if specified
if ($search_query) {
    if ($user_type === 'admins') {
        $count_query .= " WHERE email LIKE ? OR first_name LIKE ? OR last_name LIKE ?";
        $query = "SELECT * FROM Admins WHERE email LIKE ? OR first_name LIKE ? OR last_name LIKE ? ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    } else {
        $count_query .= " WHERE email LIKE ? OR first_name LIKE ? OR last_name LIKE ?";
        $query = "SELECT * FROM Users WHERE email LIKE ? OR first_name LIKE ? OR last_name LIKE ? ORDER BY created_at DESC LIMIT :limit OFFSET :offset";
    }
}

// Get total number of users
$stmt = $pdo->prepare($count_query);
if ($search_query) {
    $search_param = "%$search_query%";
    $stmt->execute([$search_param, $search_param, $search_param]);
} else {
    $stmt->execute();
}
$totalUsers = $stmt->fetchColumn();
$totalPages = ceil($totalUsers / $perPage);

// Get users
$stmt = $pdo->prepare($query);
if ($search_query) {
    $search_param = "%$search_query%";
    $stmt->bindValue(1, $search_param);
    $stmt->bindValue(2, $search_param);
    $stmt->bindValue(3, $search_param);
    $stmt->bindValue(4, $perPage, PDO::PARAM_INT);
    $stmt->bindValue(5, $offset, PDO::PARAM_INT);
} else {
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
}
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Role options for admin users
$role_options = [
    'Super Admin' => 'Super Admin',
    'Product Manager' => 'Product Manager',
    'Order Manager' => 'Order Manager'
];
?>

<!-- Main Content -->
<main class="container-fluid py-4" style="margin-top: 70px;">
    <!-- Success/Error Messages -->
    <?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['message']); endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?= htmlspecialchars($_SESSION['error']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php unset($_SESSION['error']); endif; ?>

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
        <h2 class="h3 mb-3 mb-md-0 text-primary">Users Management</h2>
        <div class="d-flex gap-2">
            <!-- User Type Tabs -->
            <!-- User Type Tabs -->
<ul class="nav nav-pills">
    <li class="nav-item">
        <a class="nav-link <?= $user_type === 'customers' ? 'active' : '' ?>" 
           href="users.php?type=customers">Customers</a>
    </li>
    <?php if (isset($_SESSION['admin_role']) && in_array($_SESSION['admin_role'], ['Super Admin', 'Product Manager'])): ?>
    <li class="nav-item">
        <a class="nav-link <?= $user_type === 'admins' ? 'active' : '' ?>" 
           href="users.php?type=admins">Admins</a>
    </li>
    <?php endif; ?>
</ul>
            
            <!-- Search Box -->
            <form method="GET" class="d-flex gap-2">
                <input type="hidden" name="type" value="<?= $user_type ?>">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" placeholder="Search users..." 
                           value="<?= htmlspecialchars($search_query) ?>">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                    <?php if ($search_query): ?>
                        <a href="users.php?type=<?= $user_type ?>" class="btn btn-outline-secondary">
                            <i class="fas fa-times"></i>
                        </a>
                    <?php endif; ?>
                </div>
                
                <?php if ($user_type === 'admins' && $_SESSION['admin_role'] === 'Super Admin'): ?>
                    <button type="button" onclick="openAddAdminModal()" class="btn btn-primary">
                        <i class="fas fa-plus me-1"></i> Add Admin
                    </button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Users Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-primary">
                        <tr>
                            <?php if ($user_type === 'customers'): ?>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            <?php else: ?>
                                <th>Admin ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Created</th>
                                <th>Last Login</th>
                                <th>Actions</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <?php if ($user_type === 'customers'): ?>
                                <td>#<?= str_pad($user['user_id'], 5, '0', STR_PAD_LEFT) ?></td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <span class="fw-bold"><?= htmlspecialchars($user['first_name']) . ' ' . htmlspecialchars($user['last_name']) ?></span>
                                        <?php if ($user['social_login_provider']): ?>
                                            <span class="badge bg-info text-dark small">
                                                <?= ucfirst($user['social_login_provider']) ?> login
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td><?= $user['phone'] ? htmlspecialchars($user['phone']) : 'N/A' ?></td>
                                <td>
                                    <?= $user['city'] ? htmlspecialchars($user['city']) . ', ' : '' ?>
                                    <?= htmlspecialchars($user['region']) ?>
                                </td>
                                <td>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">
                                        <div class="form-check form-switch">
                                            <input class="form-check-input" type="checkbox" name="is_verified" 
                                                   id="verified_<?= $user['user_id'] ?>"
                                                   <?= $user['is_verified'] ? 'checked' : '' ?>
                                                   onchange="this.form.submit()">
                                            <label class="form-check-label" for="verified_<?= $user['user_id'] ?>">
                                                <?= $user['is_verified'] ? 'Verified' : 'Pending' ?>
                                            </label>
                                        </div>
                                        <input type="hidden" name="update_user_status" value="1">
                                    </form>
                                </td>
                                <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <a href="#" class="btn btn-sm btn-outline-primary me-2">
                                        <i class="fas fa-eye me-1"></i> View
                                    </a>
                                    <a href="users.php?delete_user=<?= $user['user_id'] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>" 
                                       class="btn btn-sm btn-outline-danger" 
                                       onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.')">
                                        <i class="fas fa-trash me-1"></i> Delete
                                    </a>
                                </td>
                            <?php else: ?>
                                <td>#<?= str_pad($user['admin_id'], 3, '0', STR_PAD_LEFT) ?></td>
                                <td>
                                    <span class="fw-bold"><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></span>
                                </td>
                                <td><?= htmlspecialchars($user['email']) ?></td>
                                <td>
                                    <span class="badge <?= 
                                        $user['role'] === 'Super Admin' ? 'bg-primary' : 
                                        ($user['role'] === 'Product Manager' ? 'bg-success' : 'bg-info') ?>">
                                        <?= $user['role'] ?>
                                    </span>
                                </td>
                                <td><?= date('M j, Y', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <?= $user['last_login'] ? date('M j, Y g:i A', strtotime($user['last_login'])) : 'Never' ?>
                                </td>
                                <td>
                                    <?php if ($_SESSION['admin_role'] === 'Super Admin' || $user['admin_id'] == $_SESSION['admin_id']): ?>
                                        <button onclick="openEditAdminModal(<?= $user['admin_id'] ?>)" 
                                                class="btn btn-sm btn-outline-primary me-2">
                                            <i class="fas fa-edit me-1"></i> Edit
                                        </button>
                                    <?php endif; ?>
                                    
                                    <?php if ($_SESSION['admin_role'] === 'Super Admin' && $user['admin_id'] != $_SESSION['admin_id']): ?>
                                        <a href="users.php?delete_admin=<?= $user['admin_id'] ?>&csrf_token=<?= $_SESSION['csrf_token'] ?>" 
                                           class="btn btn-sm btn-outline-danger" 
                                           onclick="return confirm('Are you sure you want to delete this admin? This action cannot be undone.')">
                                            <i class="fas fa-trash me-1"></i> Delete
                                        </a>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <nav class="d-flex justify-content-between align-items-center mt-4">
                <div>
                    <p class="small text-muted mb-0">
                        Showing <span class="fw-bold"><?= $offset + 1 ?></span> to 
                        <span class="fw-bold"><?= min($offset + $perPage, $totalUsers) ?></span> of 
                        <span class="fw-bold"><?= $totalUsers ?></span> results
                    </p>
                </div>
                <ul class="pagination mb-0">
                    <?php if ($page > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="users.php?page=<?= $page - 1 ?>&type=<?= $user_type ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>">
                            <i class="fas fa-chevron-left"></i>
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                        <a class="page-link" href="users.php?page=<?= $i ?>&type=<?= $user_type ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>

                    <?php if ($page < $totalPages): ?>
                    <li class="page-item">
                        <a class="page-link" href="users.php?page=<?= $page + 1 ?>&type=<?= $user_type ?><?= $search_query ? '&search=' . urlencode($search_query) : '' ?>">
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add Admin Modal -->
    <div class="modal fade" id="addAdminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="actions/add_admin.php" id="addAdminForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Add New Admin</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <!-- First Name -->
                            <div class="col-md-6">
                                <label for="first_name" class="form-label">First Name *</label>
                                <input type="text" class="form-control" name="first_name" id="first_name" required>
                            </div>
                            
                            <!-- Last Name -->
                            <div class="col-md-6">
                                <label for="last_name" class="form-label">Last Name *</label>
                                <input type="text" class="form-control" name="last_name" id="last_name" required>
                            </div>
                            
                            <!-- Email -->
                            <div class="col-md-12">
                                <label for="email" class="form-label">Email *</label>
                                <input type="email" class="form-control" name="email" id="email" required>
                            </div>
                            
                            <!-- Password -->
                            <div class="col-md-6">
                                <label for="password" class="form-label">Password *</label>
                                <input type="password" class="form-control" name="password" id="password" required>
                            </div>
                            
                            <!-- Confirm Password -->
                            <div class="col-md-6">
                                <label for="confirm_password" class="form-label">Confirm Password *</label>
                                <input type="password" class="form-control" name="confirm_password" id="confirm_password" required>
                            </div>
                            
                            <!-- Role -->
                            <div class="col-md-12">
                                <label for="role" class="form-label">Role *</label>
                                <select class="form-select" name="role" id="role" required>
                                    <?php foreach ($role_options as $value => $label): ?>
                                        <option value="<?= $value ?>"><?= $label ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_admin" class="btn btn-primary">Add Admin</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editAdminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="actions/update_admin.php" id="editAdminForm">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="admin_id" id="edit_admin_id">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title">Edit Admin</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body" id="editAdminModalBody">
                        <!-- Content will be loaded dynamically -->
                        <div class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_admin" class="btn btn-primary">Update Admin</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
// Make user-related functions available globally
window.openAddAdminModal = function() {
    const modal = new bootstrap.Modal(document.getElementById('addAdminModal'));
    modal.show();
};

window.openEditAdminModal = async function(adminId) {
    try {
        // Show loading state
        document.getElementById('editAdminModalBody').innerHTML = `
            <div class="text-center py-4">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `;
        
        // Show modal immediately
        const modal = new bootstrap.Modal(document.getElementById('editAdminModal'));
        modal.show();
        
        // Fetch admin data
        const response = await fetch(`actions/get_admin.php?id=${adminId}`);
        if (!response.ok) throw new Error('Network response was not ok');
        
        const data = await response.json();
        if (!data.success) throw new Error(data.error || 'Failed to load admin data');
        
        // Populate the modal with the admin data
        const admin = data.admin;
        const isSuperAdmin = <?= ($_SESSION['admin_role'] === 'Super Admin') ? 'true' : 'false' ?>;
        
        let roleField = '';
        if (isSuperAdmin) {
            roleField = `
                <div class="col-md-12">
                    <label for="edit_role" class="form-label">Role *</label>
                    <select class="form-select" name="role" id="edit_role" required>
                        <option value="Super Admin" ${admin.role === 'Super Admin' ? 'selected' : ''}>Super Admin</option>
                        <option value="Product Manager" ${admin.role === 'Product Manager' ? 'selected' : ''}>Product Manager</option>
                        <option value="Order Manager" ${admin.role === 'Order Manager' ? 'selected' : ''}>Order Manager</option>
                    </select>
                </div>
            `;
        }
        
        let passwordFields = '';
        if (isSuperAdmin || adminId == <?= $_SESSION['admin_id'] ?? 0 ?>) {
            passwordFields = `
                <div class="col-md-6">
                    <label for="edit_password" class="form-label">New Password</label>
                    <input type="password" class="form-control" name="password" id="edit_password">
                    <small class="text-muted">Leave blank to keep current password</small>
                </div>
                <div class="col-md-6">
                    <label for="edit_confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" id="edit_confirm_password">
                </div>
            `;
        }
        
        document.getElementById('editAdminModalBody').innerHTML = `
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="edit_first_name" class="form-label">First Name *</label>
                    <input type="text" class="form-control" name="first_name" id="edit_first_name" 
                           value="${escapeHtml(admin.first_name)}" required>
                </div>
                <div class="col-md-6">
                    <label for="edit_last_name" class="form-label">Last Name *</label>
                    <input type="text" class="form-control" name="last_name" id="edit_last_name" 
                           value="${escapeHtml(admin.last_name)}" required>
                </div>
                <div class="col-md-12">
                    <label for="edit_email" class="form-label">Email *</label>
                    <input type="email" class="form-control" name="email" id="edit_email" 
                           value="${escapeHtml(admin.email)}" required>
                </div>
                ${passwordFields}
                ${roleField}
            </div>
        `;
        
        // Set the admin ID in the hidden field
        document.getElementById('edit_admin_id').value = adminId;
        
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('editAdminModalBody').innerHTML = `
            <div class="alert alert-danger">
                Failed to load admin data: ${escapeHtml(error.message)}
            </div>
        `;
    }
};


// Function to populate edit admin modal
function populateEditAdminModal(admin) {
    const formContent = `
        <div class="row g-3">
            <!-- First Name -->
            <div class="col-md-6">
                <label for="edit_first_name" class="form-label">First Name *</label>
                <input type="text" class="form-control" name="first_name" id="edit_first_name" 
                       value="${escapeHtml(admin.first_name)}" required>
            </div>
            
            <!-- Last Name -->
            <div class="col-md-6">
                <label for="edit_last_name" class="form-label">Last Name *</label>
                <input type="text" class="form-control" name="last_name" id="edit_last_name" 
                       value="${escapeHtml(admin.last_name)}" required>
            </div>
            
            <!-- Email -->
            <div class="col-md-12">
                <label for="edit_email" class="form-label">Email *</label>
                <input type="email" class="form-control" name="email" id="edit_email" 
                       value="${escapeHtml(admin.email)}" required>
            </div>
            
            <!-- Password (only if super admin) -->
            ${(admin.role === 'Super Admin' || <?= ($_SESSION['admin_role'] === 'Super Admin') ? 'true' : 'false' ?>) ? `
                <div class="col-md-6">
                    <label for="edit_password" class="form-label">New Password</label>
                    <input type="password" class="form-control" name="password" id="edit_password">
                    <small class="text-muted">Leave blank to keep current password</small>
                </div>
                
                <div class="col-md-6">
                    <label for="edit_confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" name="confirm_password" id="edit_confirm_password">
                </div>
            ` : ''}
            
            <!-- Role (only for super admin) -->
            ${<?= ($_SESSION['admin_role'] === 'Super Admin') ? 'true' : 'false' ?> ? `
                <div class="col-md-12">
                    <label for="edit_role" class="form-label">Role *</label>
                    <select class="form-select" name="role" id="edit_role" required>
                        ${generateRoleOptions(admin.role)}
                    </select>
                </div>
            ` : ''}
        </div>
    `;
    
    // Set the admin ID
    document.getElementById('edit_admin_id').value = admin.admin_id;
    
    // Update the modal body
    document.getElementById('editAdminModalBody').innerHTML = formContent;
}


// Helper function to generate role options
function generateRoleOptions(selectedRole) {
    const roles = {
        'Super Admin': 'Super Admin',
        'Product Manager': 'Product Manager',
        'Order Manager': 'Order Manager'
    };
    
    return Object.entries(roles).map(([value, label]) => `
        <option value="${value}" ${value === selectedRole ? 'selected' : ''}>${label}</option>
    `).join('');
}

// Helper function to escape HTML
function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe.toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Add form validation for password match
document.addEventListener('DOMContentLoaded', function() {
    const addAdminForm = document.getElementById('addAdminForm');
    const editAdminForm = document.getElementById('editAdminForm');
    
    if (addAdminForm) {
        addAdminForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                e.preventDefault();
                showNotification('error', 'Passwords do not match');
                return false;
            }
            return true;
        });
    }
    
    if (editAdminForm) {
        editAdminForm.addEventListener('submit', function(e) {
            const password = document.getElementById('edit_password')?.value;
            const confirmPassword = document.getElementById('edit_confirm_password')?.value;
            
            if (password && password !== confirmPassword) {
                e.preventDefault();
                showNotification('error', 'Passwords do not match');
                return false;
            }
            return true;
        });
    }
});
</script>

<?php 
require_once __DIR__ . '/includes/footer.php';
?>