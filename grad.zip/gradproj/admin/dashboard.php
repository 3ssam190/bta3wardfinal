<?php 
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/topbar.php';
?>

<!-- Main Content -->
<!-- Main Content -->
<main class="container-fluid py-4">
    <h2 class="h3 mb-4 text-plant-dark">Dashboard Overview</h2>
    
    <!-- Cards -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card border-start border-plant-success shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h3 class="h5 card-title text-plant-secondary">Total Products</h3>
                            <p class="display-6 fw-bold text-plant-dark">123</p>
                        </div>
                        <div class="icon-circle bg-plant-primary-light">
                            <i class="fas fa-leaf text-white"></i>
                        </div>
                    </div>
                    <div class="progress mt-3" style="height: 6px;">
                        <div class="progress-bar bg-plant-success" role="progressbar" style="width: 75%;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start border-plant-info shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h3 class="h5 card-title text-plant-secondary">Orders</h3>
                            <p class="display-6 fw-bold text-plant-dark">45</p>
                        </div>
                        <div class="icon-circle bg-plant-info-light">
                            <i class="fas fa-shopping-cart text-white"></i>
                        </div>
                    </div>
                    <div class="progress mt-3" style="height: 6px;">
                        <div class="progress-bar bg-plant-info" role="progressbar" style="width: 45%;"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-start border-plant-warning shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h3 class="h5 card-title text-plant-secondary">Users</h3>
                            <p class="display-6 fw-bold text-plant-dark">89</p>
                        </div>
                        <div class="icon-circle bg-plant-warning-light">
                            <i class="fas fa-users text-white"></i>
                        </div>
                    </div>
                    <div class="progress mt-3" style="height: 6px;">
                        <div class="progress-bar bg-plant-warning" role="progressbar" style="width: 60%;"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Orders -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-plant-primary text-white d-flex justify-content-between align-items-center">
            <h3 class="h5 mb-0">Recent Orders</h3>
            <a href="orders.php" class="btn btn-sm btn-outline-light">View All</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover table-plant">
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>#00123</td>
                            <td>Alice</td>
                            <td>$120</td>
                            <td><span class="badge bg-plant-success">Shipped</span></td>
                        </tr>
                        <tr>
                            <td>#00122</td>
                            <td>Bob</td>
                            <td>$85</td>
                            <td><span class="badge bg-plant-warning">Pending</span></td>
                        </tr>
                        <tr>
                            <td>#00121</td>
                            <td>Charlie</td>
                            <td>$50</td>
                            <td><span class="badge bg-plant-danger">Cancelled</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<?php 
require_once __DIR__ . '/includes/footer.php';
?>