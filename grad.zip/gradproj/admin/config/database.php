<?php
class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        try {
            $this->pdo = new PDO(
                'mysql:host=localhost;dbname=u578375581_plants_store',
                'u578375581_plants_admin',
                'ESAM123esam@',
                [
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4',
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::ATTR_PERSISTENT => false
                ]
            );
        } catch (PDOException $e) {
            // Log error to file
            error_log(date('[Y-m-d H:i:s] ') . 'Database Error: ' . $e->getMessage() . "\n", 3, __DIR__ . '/database_errors.log');
            
            // Display user-friendly message
            if (strpos($_SERVER['REQUEST_URI'], '/admin/') !== false) {
                die("Database connection error. Please check the admin configuration.");
            } else {
                die("We're experiencing technical difficulties. Please try again later.");
            }
        }
    }
    
    public static function connect() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->pdo;
    }
    
    // Prevent cloning and serialization
    private function __clone() {}
    public function __wakeup() {
        throw new Exception("Cannot unserialize a singleton.");
    }
}