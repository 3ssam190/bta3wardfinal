<?php
// MUST be first line - no whitespace before!
header('Content-Type: application/json');

// Disable displaying errors to users
ini_set('display_errors', 0);
ini_set('log_errors', 1);

require_once __DIR__ . '/../../config.php';

try {
    // Verify session
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if cart exists
    if (!isset($_SESSION['cart_id'])) {
        throw new Exception('No active cart found');
    }

    // Delete all cart items
    $stmt = $conn->prepare("DELETE FROM CartItems WHERE cart_id = ?");
    if (!$stmt->execute([$_SESSION['cart_id']])) {
        throw new Exception('Failed to empty cart');
    }

    // Update session count
    $_SESSION['cart_count'] = 0;

    // Return success
    echo json_encode([
        'success' => true,
        'message' => 'Cart emptied successfully',
        'cartCount' => 0
    ]);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
    exit;
}