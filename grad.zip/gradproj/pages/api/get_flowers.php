<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config.php';

$response = ['success' => false, 'data' => []];

try {
    // Get flower IDs from request (either GET or POST)
    $flowerIds = [];
    
    if (isset($_GET['ids'])) {
        // Handle comma-separated string of IDs
        $flowerIds = is_array($_GET['ids']) ? $_GET['ids'] : explode(',', $_GET['ids']);
    } elseif (isset($_POST['ids'])) {
        // Handle POSTed array of IDs
        $flowerIds = is_array($_POST['ids']) ? $_POST['ids'] : explode(',', $_POST['ids']);
    } elseif ($json = file_get_contents('php://input')) {
        // Handle JSON input
        $data = json_decode($json, true);
        if (isset($data['ids'])) {
            $flowerIds = is_array($data['ids']) ? $data['ids'] : explode(',', $data['ids']);
        }
    }

    // Prepare the query
    $query = "SELECT * FROM Flowers";
    $params = [];
    
    if (!empty($flowerIds)) {
        $placeholders = implode(',', array_fill(0, count($flowerIds), '?'));
        $query .= " WHERE id IN ($placeholders)";
        $params = $flowerIds;
    }

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $flowers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $response = [
        'success' => true,
        'data' => $flowers
    ];

} catch (PDOException $e) {
    $response['error'] = 'Database error: ' . $e->getMessage();
    error_log("PDO Error: " . $e->getMessage());
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
    error_log("Error: " . $e->getMessage());
}

echo json_encode($response);