<?php
header('Content-Type: application/json');
session_start();
require_once __DIR__ . '/../../config.php';

$response = ['success' => false, 'message' => '', 'cart_count' => 0];

try {
    // Validate session
    if (!isset($_SESSION['user_id'])) {
        $_SESSION['user_id'] = null; // Handle guest users
    }

    // Get input data
    $json = file_get_contents('php://input');
    if (!$json) {
        throw new Exception('No data received');
    }
    
    $data = json_decode($json, true);
    if (!$data) {
        throw new Exception('Invalid JSON data');
    }

    // Validate required fields
    $required = ['cover_id', 'flower_count', 'flowers', 'total_price'];
    foreach ($required as $field) {
        if (!isset($data[$field])) {
            throw new Exception("Missing required field: $field");
        }
    }

    // Validate flower data
    if (!is_array($data['flowers']) || count($data['flowers']) === 0) {
        throw new Exception('Invalid flowers data');
    }

    // Get or create cart
    $userId = $_SESSION['user_id'];
    $sessionId = session_id();
    
    $stmt = $conn->prepare("
        INSERT INTO Carts (user_id, session_id) 
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$userId, $sessionId]);
    
    if ($userId) {
        $cartId = $conn->lastInsertId();
    } else {
        $stmt = $conn->prepare("SELECT cart_id FROM Carts WHERE session_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$sessionId]);
        $cart = $stmt->fetch();
        $cartId = $cart ? $cart['cart_id'] : $conn->lastInsertId();
    }

    // Prepare custom data
    $customData = [
        'cover_id' => (int)$data['cover_id'],
        'flower_count' => (int)$data['flower_count'],
        'flowers' => array_map(function($flower) {
            return [
                'id' => (int)$flower['id'],
                'quantity' => (int)$flower['quantity']
            ];
        }, $data['flowers'])
    ];

    // Insert into CartItems
    $stmt = $conn->prepare("
        INSERT INTO CartItems 
        (cart_id, is_custom, custom_type, custom_data, quantity, price) 
        VALUES (?, 1, 'bouquet', ?, 1, ?)
    ");
    
    $success = $stmt->execute([
        $cartId,
        json_encode($customData),
        round((float)$data['total_price'], 2)
    ]);

    if (!$success) {
        throw new Exception('Failed to save bouquet to cart');
    }

    // Get updated cart count
    $stmt = $conn->prepare("
        SELECT COALESCE(SUM(quantity), 0) as count 
        FROM CartItems 
        WHERE cart_id = ?
    ");
    $stmt->execute([$cartId]);
    $result = $stmt->fetch();
    
    // Update session
    $_SESSION['cart_count'] = (int)$result['count'];
    $_SESSION['cart_id'] = $cartId;
    
    $response = [
        'success' => true,
        'message' => 'Bouquet added to cart successfully',
        'cart_count' => (int)$result['count']
    ];

} catch (PDOException $e) {
    $response['message'] = 'Database error: ' . $e->getMessage();
    error_log("PDO Error: " . $e->getMessage());
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Error: " . $e->getMessage());
}

echo json_encode($response);