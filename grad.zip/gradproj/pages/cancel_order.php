<?php
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit();
}

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit();
}

$orderId = $_POST['order_id'] ?? null;
if (!$orderId) {
    echo json_encode(['success' => false, 'message' => 'Order ID required']);
    exit();
}

try {
    // Verify order belongs to user
    $stmt = $conn->prepare("SELECT user_id FROM Orders WHERE order_id = ?");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order || $order['user_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'Order not found']);
        exit();
    }
    
    // Update order status
    $stmt = $conn->prepare("UPDATE Orders SET status = 'Cancelled' WHERE order_id = ?");
    $stmt->execute([$orderId]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}