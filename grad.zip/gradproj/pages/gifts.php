<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="gift-builder-container">
    <!-- Animated Background Elements -->
    <div class="romantic-elements">
        <div class="heart-animation heart-1"></div>
        <div class="heart-animation heart-2"></div>
        <div class="heart-animation heart-3"></div>
        <div class="floating-rose rose-1"></div>
        <div class="floating-rose rose-2"></div>
    </div>
    
    <!-- Progress Steps - Modern Design -->
    <div class="progress-tracker">
        <div class="progress-bar">
            <div class="progress-fill" style="width: 0%"></div>
        </div>
        <div class="steps-container">
            <div class="step active" data-step="1">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M12,2L4.5,20.29L5.21,21L12,18L18.79,21L19.5,20.29L12,2Z" />
                    </svg>
                </div>
                <span class="step-label"><?php echo __('choose_cover'); ?></span>
            </div>
            <div class="step" data-step="2">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M12,3L2,12H5V20H19V12H22L12,3Z" />
                    </svg>
                </div>
                <span class="step-label"><?php echo __('select_size'); ?></span>
            </div>
            <div class="step" data-step="3">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M15.5,8C16.3,8 17,8.7 17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8M8.5,8C9.3,8 10,8.7 10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8M3.5,11C4.3,11 5,11.7 5,12.5C5,13.3 4.3,14 3.5,14C2.7,14 2,13.3 2,12.5C2,11.7 2.7,11 3.5,11M5,3H8V5H5V10H3V5H0V3H3V0H5V3M19,0H21V3H24V5H21V10H19V5H16V3H19V0M12,12C14.67,12 20,13.34 20,16V18H4V16C4,13.34 9.33,12 12,12Z" />
                    </svg>
                </div>
                <span class="step-label"><?php echo __('add_flowers'); ?></span>
            </div>
            <div class="step" data-step="4">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24">
                        <path d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" />
                    </svg>
                </div>
                <span class="step-label"><?php echo __('review'); ?></span>
            </div>
        </div>
    </div>

    <div class="builder-content">
        <!-- Products Selection Panel -->
        <div class="products-panel" id="products-container">
            <!-- Dynamic content loaded based on step -->
            <div class="panel-header">
                <h3 class="panel-title"></h3>
                <div class="step-counter">
                    <span class="current-step">1</span> / 4
                </div>
            </div>
            <div class="products-grid"></div>
        </div>

        <!-- Bouquet Preview Panel -->
        <div class="preview-panel">
            <div class="preview-container">
                <div class="bouquet-display">
                    <div class="cover-preview animated-cover">
                        <div class="cover-image"></div>
                        <div class="bouquet-circle">
                            <div class="flowers-preview"></div>
                            <div class="circle-decoration"></div>
                            <div class="circle-decoration-2"></div>
                        </div>
                    </div>
                    <div class="bouquet-shine"></div>
                </div>
                
                <div class="bouquet-summary">
                    <h3 class="summary-title"><?php echo __('your_custom_bouquet'); ?></h3>
                    <div class="summary-details"></div>
                    
                    <div class="builder-navigation">
                        <button class="btn btn-prev" id="prev-btn">
                            <svg viewBox="0 0 24 24">
                                <path d="M15.41,16.58L10.83,12L15.41,7.41L14,6L8,12L14,18L15.41,16.58Z" />
                            </svg>
                            Previous
                        </button>
                        <button class="btn btn-next" id="next-btn" disabled>
                            Next
                            <svg viewBox="0 0 24 24">
                                <path d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Confetti Effect Container -->
<div class="confetti-container"></div>

<style>
/* Modern Color Palette */
:root {
    --primary-color: #ff6b8b;
    --primary-dark: #ff4757;
    --secondary-color: #ffb8c6;
    --accent-color: #ff9eb5;
    --light-color: #fff5f7;
    --dark-color: #2d3436;
    --success-color: #55efc4;
    --shadow-color: rgba(255, 107, 139, 0.3);
}

/* Base Styles */
.gift-builder-container {
    position: relative;
    min-height: calc(100vh - 150px);
    padding: 2rem;
    overflow: hidden;
    background-color: var(--light-color);
    background-image: radial-gradient(circle at 10% 20%, rgba(255, 184, 198, 0.1) 0%, rgba(255, 255, 255, 1) 90%);
}

/* Romantic Animated Elements */
.romantic-elements {
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    pointer-events: none;
    z-index: 0;
}

.heart-animation {
    position: absolute;
    background-color: var(--primary-color);
    opacity: 0.15;
    border-radius: 50%;
    animation: float 15s infinite linear;
}

.heart-1 {
    width: 100px;
    height: 100px;
    top: 10%;
    left: 5%;
    animation-delay: 0s;
}

.heart-2 {
    width: 60px;
    height: 60px;
    top: 60%;
    left: 80%;
    animation-delay: 3s;
}

.heart-3 {
    width: 80px;
    height: 80px;
    top: 30%;
    left: 70%;
    animation-delay: 6s;
}

.floating-rose {
    position: absolute;
    width: 50px;
    height: 50px;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    opacity: 0.1;
    animation: float 20s infinite ease-in-out;
}

.rose-1 {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="%23ff6b8b" d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M15.5,8C16.3,8 17,8.7 17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8M8.5,8C9.3,8 10,8.7 10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8M3.5,11C4.3,11 5,11.7 5,12.5C5,13.3 4.3,14 3.5,14C2.7,14 2,13.3 2,12.5C2,11.7 2.7,11 3.5,11M5,3H8V5H5V10H3V5H0V3H3V0H5V3M19,0H21V3H24V5H21V10H19V5H16V3H19V0M12,12C14.67,12 20,13.34 20,16V18H4V16C4,13.34 9.33,12 12,12Z" /></svg>');
    top: 20%;
    left: 85%;
    animation-delay: 2s;
}

.rose-2 {
    background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path fill="%23ff6b8b" d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M15.5,8C16.3,8 17,8.7 17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8M8.5,8C9.3,8 10,8.7 10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8M3.5,11C4.3,11 5,11.7 5,12.5C5,13.3 4.3,14 3.5,14C2.7,14 2,13.3 2,12.5C2,11.7 2.7,11 3.5,11M5,3H8V5H5V10H3V5H0V3H3V0H5V3M19,0H21V3H24V5H21V10H19V5H16V3H19V0M12,12C14.67,12 20,13.34 20,16V18H4V16C4,13.34 9.33,12 12,12Z" /></svg>');
    top: 70%;
    left: 15%;
    animation-delay: 5s;
}

@keyframes float {
    0% {
        transform: translateY(0) rotate(0deg);
    }
    50% {
        transform: translateY(-20px) rotate(180deg);
    }
    100% {
        transform: translateY(0) rotate(360deg);
    }
}

/* Progress Tracker - Modern Design */
.progress-tracker {
    margin-bottom: 2.5rem;
    position: relative;
    z-index: 1;
}

.progress-bar {
    height: 6px;
    background-color: #f0f0f0;
    border-radius: 3px;
    position: absolute;
    top: 24px;
    left: 0;
    right: 0;
    margin: 0 12%;
    z-index: 0;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
    border-radius: 3px;
    transition: width 0.5s ease;
}

.steps-container {
    display: flex;
    justify-content: space-between;
    position: relative;
    z-index: 1;
    padding: 0 10%;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
    cursor: pointer;
    transition: all 0.3s ease;
    opacity: 0.5;
    transform: scale(0.9);
}

.step.active {
    opacity: 1;
    transform: scale(1);
}

.step-icon {
    width: 48px;
    height: 48px;
    background-color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 12px var(--shadow-color);
    margin-bottom: 8px;
    transition: all 0.3s ease;
    position: relative;
    z-index: 1;
}

.step.active .step-icon {
    background-color: var(--primary-color);
    color: white;
}

.step-icon svg {
    width: 24px;
    height: 24px;
    fill: var(--dark-color);
    transition: all 0.3s ease;
}

.step.active .step-icon svg {
    fill: white;
}

.step-label {
    font-size: 14px;
    font-weight: 500;
    color: var(--dark-color);
    text-align: center;
    transition: all 0.3s ease;
}

.step.active .step-label {
    color: var(--primary-dark);
    font-weight: 600;
}

/* Main Content Layout */
.builder-content {
    display: flex;
    gap: 2rem;
    min-height: 600px;
    position: relative;
    z-index: 1;
}

.products-panel {
    flex: 1;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    padding: 1.5rem;
    display: flex;
    flex-direction: column;
    transition: all 0.3s ease;
    border: 1px solid rgba(255, 107, 139, 0.2);
    overflow: hidden;
}

.panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.panel-title {
    font-size: 1.5rem;
    color: var(--dark-color);
    font-weight: 600;
    margin: 0;
    position: relative;
}

.panel-title::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 0;
    width: 40px;
    height: 3px;
    background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
    border-radius: 3px;
}

.step-counter {
    background-color: var(--light-color);
    color: var(--primary-dark);
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 600;
}

.products-grid {
    flex: 1;
    overflow-y: auto;
    padding: 4px;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
    gap: 1rem;
    align-content: start;
}

.preview-panel {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.preview-container {
    flex: 1;
    background-color: white;
    border-radius: 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
    padding: 2rem;
    display: flex;
    flex-direction: column;
    border: 1px solid rgba(255, 107, 139, 0.2);
    position: relative;
    overflow: hidden;
}

.bouquet-display {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    margin-bottom: 2rem;
}

.animated-cover {
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    width: 100%;
    height: 300px;
    perspective: 1000px;
}

.cover-image {
    width: 200px;
    height: 200px;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    transition: all 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    transform-style: preserve-3d;
    position: relative;
    z-index: 2;
}

.bouquet-circle {
    width: 300px;
    height: 300px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--light-color), white);
    display: flex;
    justify-content: center;
    align-items: center;
    position: relative;
    box-shadow: 0 10px 30px rgba(255, 107, 139, 0.2);
    transition: all 0.5s ease;
    margin-left: -50px;
}

.flowers-preview {
    width: 90%;
    height: 90%;
    border-radius: 50%;
    position: relative;
}

.circle-decoration {
    position: absolute;
    width: 110%;
    height: 110%;
    border-radius: 50%;
    border: 2px dashed var(--secondary-color);
    animation: rotate 60s linear infinite;
}

.circle-decoration-2 {
    position: absolute;
    width: 120%;
    height: 120%;
    border-radius: 50%;
    border: 1px dashed rgba(255, 107, 139, 0.3);
    animation: rotate 120s linear infinite reverse;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.bouquet-shine {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: radial-gradient(circle at center, rgba(255, 255, 255, 0.8) 0%, rgba(255, 255, 255, 0) 70%);
    pointer-events: none;
    opacity: 0.5;
}

/* Product Items */
.product-item {
    background-color: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    cursor: pointer;
    position: relative;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.product-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px var(--shadow-color);
    border-color: var(--primary-color);
}

.product-item::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: 12px;
    box-shadow: inset 0 0 0 1px rgba(255, 107, 139, 0);
    transition: all 0.3s ease;
    pointer-events: none;
}

.product-item.selected::after {
    box-shadow: inset 0 0 0 2px var(--primary-color);
}

.product-item img {
    width: 100%;
    height: 140px;
    object-fit: contain;
    padding: 1rem;
    background-color: var(--light-color);
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
}

.product-item h4 {
    font-size: 14px;
    margin: 0.5rem;
    color: var(--dark-color);
    font-weight: 500;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.product-item p {
    font-size: 14px;
    margin: 0.5rem;
    color: var(--primary-dark);
    font-weight: 600;
    text-align: center;
}

.size-option {
    background-color: white;
    border-radius: 12px;
    padding: 1rem;
    text-align: center;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.05);
}

.size-option:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 16px var(--shadow-color);
}

.size-option.selected {
    background-color: var(--primary-color);
    color: white;
    box-shadow: 0 4px 16px var(--shadow-color);
    border-color: var(--primary-color);
}

/* Flowers in Bouquet */
.flower-in-bouquet {
    position: absolute;
    width: 40px;
    height: 40px;
    background-size: contain;
    background-repeat: no-repeat;
    background-position: center;
    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    cursor: move;
    z-index: 10;
    filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
}

.flower-in-bouquet:hover {
    transform: scale(1.3) rotate(10deg);
    z-index: 20;
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));
}

/* Summary Area */
.bouquet-summary {
    margin-top: 2rem;
    padding-top: 2rem;
    border-top: 1px solid rgba(0, 0, 0, 0.1);
}

.summary-title {
    font-size: 1.25rem;
    color: var(--dark-color);
    margin-bottom: 1rem;
    text-align: center;
    position: relative;
}

.summary-title::after {
    content: '';
    position: absolute;
    bottom: -8px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 3px;
    background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
    border-radius: 3px;
}

.summary-details {
    margin-bottom: 1.5rem;
}

.flower-summary {
    max-height: 200px;
    overflow-y: auto;
    margin: 1rem 0;
    padding: 1rem;
    background-color: var(--light-color);
    border-radius: 12px;
    border: 1px solid rgba(0, 0, 0, 0.05);
}

/* Navigation Buttons */
.builder-navigation {
    display: flex;
    justify-content: space-between;
    margin-top: 2rem;
}

.btn {
    padding: 0.75rem 1.5rem;
    border-radius: 50px;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    border: none;
    cursor: pointer;
}

.btn svg {
    width: 20px;
    height: 20px;
    margin: 0 4px;
    transition: all 0.3s ease;
}

.btn-prev {
    background-color: white;
    color: var(--dark-color);
    border: 1px solid rgba(0, 0, 0, 0.1);
}

.btn-prev:hover {
    background-color: #f8f8f8;
    border-color: rgba(0, 0, 0, 0.2);
}

.btn-prev svg {
    margin-right: 8px;
}

.btn-next {
    background: linear-gradient(90deg, var(--primary-color), var(--primary-dark));
    color: white;
    box-shadow: 0 4px 12px var(--shadow-color);
}

.btn-next:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px var(--shadow-color);
}

.btn-next:disabled {
    background: #cccccc;
    box-shadow: none;
    transform: none;
    cursor: not-allowed;
}

.btn-next svg {
    margin-left: 8px;
    fill: white;
}

#add-to-cart-btn {
    background: linear-gradient(90deg, var(--success-color), #00b894);
    color: white;
    width: 100%;
    padding: 1rem;
    font-size: 1rem;
    font-weight: 600;
    box-shadow: 0 4px 12px rgba(85, 239, 196, 0.3);
}

#add-to-cart-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(85, 239, 196, 0.4);
}

/* Confetti Effect */
.confetti-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1000;
    display: none;
}

.confetti {
    position: absolute;
    width: 10px;
    height: 10px;
    background-color: var(--primary-color);
    opacity: 0;
    animation: confetti-fall 5s linear forwards;
}

@keyframes confetti-fall {
    0% {
        transform: translateY(-100px) rotate(0deg);
        opacity: 1;
    }
    100% {
        transform: translateY(100vh) rotate(360deg);
        opacity: 0;
    }
}

/* Responsive Design */
@media (max-width: 1200px) {
    .bouquet-circle {
        width: 250px;
        height: 250px;
    }
    
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    }
}

@media (max-width: 992px) {
    .builder-content {
        flex-direction: column;
    }
    
    .bouquet-display {
        margin-bottom: 1rem;
    }
    
    .bouquet-summary {
        margin-top: 1rem;
        padding-top: 1rem;
    }
}

@media (max-width: 768px) {
    .gift-builder-container {
        padding: 1rem;
    }
    
    .steps-container {
        padding: 0 5%;
    }
    
    .step-icon {
        width: 36px;
        height: 36px;
    }
    
    .step-icon svg {
        width: 18px;
        height: 18px;
    }
    
    .step-label {
        font-size: 12px;
    }
    
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    }
    
    .bouquet-circle {
        width: 200px;
        height: 200px;
    }
}

@media (max-width: 576px) {
    .progress-bar {
        margin: 0 15%;
    }
    
    .steps-container {
        padding: 0;
    }
    
    .step {
        transform: scale(0.8);
    }
    
    .step.active {
        transform: scale(0.9);
    }
    
    .products-grid {
        grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
    }
}
</style>

<script src="https://cdn.jsdelivr.net/npm/interactjs/dist/interact.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.9.1/gsap.min.js"></script>

<script>
// Enhanced JavaScript with animations and romantic touches
document.addEventListener('DOMContentLoaded', function() {
    if (typeof jQuery == 'undefined') {
        console.error('jQuery is not loaded!');
        return;
    }
    
    jQuery(function($) {
        // Constants
        const CURRENCY = '<?php echo CURRENCY; ?>';
        const BASE_URL = '<?php echo BASE_URL; ?>';
        
        // Global variables
        let currentStep = 1;
        let selectedCover = null;
        let selectedSize = null;
        let selectedFlowers = [];
        let flowerCount = 0;
        
        // Initialize builder with animation
        function initBuilder() {
            gsap.from('.step', {
                duration: 0.5,
                opacity: 0,
                y: 20,
                stagger: 0.1,
                ease: "back.out"
            });
            
            gsap.from('.builder-content > *', {
                duration: 0.8,
                opacity: 0,
                y: 40,
                stagger: 0.2,
                delay: 0.3,
                ease: "power2.out"
            });
            
            loadStep(currentStep);
        }
        
        // Load step with animation
        function loadStep(step) {
            $('.products-grid').fadeOut(200, function() {
                $(this).empty();
                
                switch(step) {
                    case 1: loadCoversStep(); break;
                    case 2: loadSizeStep(); break;
                    case 3: loadFlowersStep(); break;
                    case 4: showSummary(); break;
                }
                
                updateStepCounter();
                updateProgressBar();
                
                $(this).fadeIn(200);
            });
        }
        
        // Update step counter
        function updateStepCounter() {
            $('.current-step').text(currentStep);
            $('.panel-title').text(getStepTitle(currentStep));
            
            // Animate step change
            gsap.from('.panel-title', {
                duration: 0.3,
                y: -10,
                opacity: 0,
                ease: "power1.out"
            });
        }
        
        // Get step title
        function getStepTitle(step) {
            switch(step) {
                case 1: return '<?php echo __('choose_cover'); ?>';
                case 2: return '<?php echo __('select_size'); ?>';
                case 3: return '<?php echo __('add_flowers'); ?>';
                case 4: return '<?php echo __('review'); ?>';
                default: return '';
            }
        }
        
        // Update progress bar
        function updateProgressBar() {
            const progress = ((currentStep - 1) / 3) * 100;
            $('.progress-fill').css('width', progress + '%');
            
            // Update step indicators
            $('.step').removeClass('active').css('opacity', '0.5').css('transform', 'scale(0.9)');
            $(`.step[data-step="${currentStep}"]`).addClass('active').css('opacity', '1').css('transform', 'scale(1)');
            
            // Animate active step
            gsap.from(`.step[data-step="${currentStep}"]`, {
                duration: 0.5,
                scale: 1.2,
                ease: "elastic.out(1, 0.5)"
            });
        }
        
        // Step 1: Load covers
        function loadCoversStep() {
            let html = '';
            $.get('api/get_bouquet_covers.php', function(data) {
                data.forEach(cover => {
                    html += `
                        <div class="product-item" data-id="${cover.id}" data-price="${cover.price}">
                            <img src="../admin/assets/images/covers/${cover.image_url}" alt="${cover.name}" 
                                 onerror="this.onerror=null;this.src='${BASE_URL}/assets/images/default-cover.png'">
                            <h4>${cover.name}</h4>
                            <p>${cover.price} ${CURRENCY}</p>
                        </div>
                    `;
                });
                
                $('.products-grid').html(html);
                
                $('.product-item').on('click', function() {
                    const id = $(this).data('id');
                    selectCover(id, $(this).find('img').attr('src'));
                    
                    // Animate selection
                    gsap.to($(this), {
                        duration: 0.3,
                        scale: 1.05,
                        boxShadow: '0 8px 20px rgba(255, 107, 139, 0.4)',
                        borderColor: 'var(--primary-color)',
                        ease: "power2.out"
                    });
                });
            });
        }
        
        // Step 2: Load sizes
        function loadSizeStep() {
            let html = '';
            const sizes = [
                { count: 20, name: '<?php echo __('small_bouquet'); ?>' },
                { count: 30, name: '<?php echo __('medium_bouquet'); ?>' },
                { count: 40, name: '<?php echo __('large_bouquet'); ?>' },
                { count: 50, name: '<?php echo __('luxury_bouquet'); ?>' }
            ];
            
            sizes.forEach(size => {
                html += `
                    <div class="size-option" data-size="${size.count}">
                        <h4>${size.count} <?php echo __('flowers'); ?></h4>
                        <p>${size.name}</p>
                    </div>
                `;
            });
            
            $('.products-grid').html(html);
            
            $('.size-option').on('click', function() {
                $('.size-option').removeClass('selected');
                $(this).addClass('selected');
                selectedSize = $(this).data('size');
                flowerCount = 0;
                selectedFlowers = [];
                $('.flowers-preview').empty();
                $('#next-btn').prop('disabled', false);
                
                // Animate bouquet circle size change
                gsap.to('.bouquet-circle', {
                    duration: 0.5,
                    scale: 1 + (selectedSize / 100),
                    ease: "elastic.out(1, 0.5)"
                });
                
                // Animate selection
                gsap.to($(this), {
                    duration: 0.3,
                    scale: 1.05,
                    ease: "back.out"
                });
            });
        }
        
        // Step 3: Load flowers
        function loadFlowersStep() {
            let html = '';
            const apiPath = 'api/get_flowers.php';
            
            $.get(apiPath, function(response) {
                if (response.success && response.data) {
                    response.data.forEach(flower => {
                        const imageUrl = flower.image_url ? 
                            `${BASE_URL}/admin/assets/images/flowers/${flower.image_url}` : 
                            `${BASE_URL}/assets/images/default-flower.png`;
                        
                        html += `
                            <div class="product-item flower-item" 
                                 data-id="${flower.id}" 
                                 data-price="${flower.price_per_unit}"
                                 draggable="true">
                                <img src="${imageUrl}" 
                                     alt="${flower.name}"
                                     onerror="this.onerror=null;this.src='${BASE_URL}/assets/images/default-flower.png'">
                                <h4>${flower.name}</h4>
                                <p>${CURRENCY}${parseFloat(flower.price_per_unit).toFixed(2)}</p>
                            </div>
                        `;
                    });
                    
                    $('.products-grid').html(html);
                    setupFlowerInteractions();
                } else {
                    showError('Failed to load flowers. Please try again later.');
                }
            }).fail(function() {
                showError('Could not connect to server. Please check your connection.');
            });
        }
        
        // Setup flower drag and drop with animations
        function setupFlowerInteractions() {
            interact('.flower-item').draggable({
                inertia: true,
                autoScroll: true,
                onstart: function(event) {
                    gsap.to(event.target, {
                        duration: 0.3,
                        scale: 1.2,
                        zIndex: 100,
                        ease: "power2.out"
                    });
                },
                onmove: dragMoveListener,
                onend: function(event) {
                    gsap.to(event.target, {
                        duration: 0.3,
                        scale: 1,
                        zIndex: 1,
                        ease: "power2.out"
                    });
                    
                    if (isOverBouquet(event)) {
                        const flowerId = $(event.target).data('id');
                        addFlowerToBouquet(flowerId, $(event.target).find('img').attr('src'));
                    }
                }
            });
            
            $('.flower-item').on('click', function() {
                if (flowerCount < selectedSize) {
                    const flowerId = $(this).data('id');
                    addFlowerToBouquet(flowerId, $(this).find('img').attr('src'));
                    
                    // Animate click
                    gsap.to($(this), {
                        duration: 0.3,
                        scale: 0.9,
                        y: -5,
                        ease: "back.out(1.7)"
                    });
                } else {
                    showMessage('You have reached the maximum number of flowers for this bouquet.');
                }
            });
        }
        
        // Select cover with animation
        function selectCover(id, imageUrl) {
            selectedCover = id;
            
            // Animate cover selection
            gsap.to('.cover-image', {
                duration: 0.5,
                opacity: 0,
                rotationY: 90,
                onComplete: function() {
                    $('.cover-image').css('background-image', `url(${imageUrl})`);
                    gsap.to('.cover-image', {
                        duration: 0.5,
                        opacity: 1,
                        rotationY: 0,
                        ease: "back.out"
                    });
                }
            });
            
            $('#next-btn').prop('disabled', false);
            
            // Heart pulse animation
            gsap.to('.heart-animation', {
                duration: 0.5,
                scale: 1.2,
                opacity: 0.3,
                repeat: 1,
                yoyo: true,
                ease: "power1.out"
            });
        }
        
        // Add flower to bouquet with romantic animation
        function addFlowerToBouquet(flowerId, imageUrl) {
            if (flowerCount < selectedSize) {
                flowerCount++;
                selectedFlowers.push(flowerId);
                
                // Calculate position in circle with spiral effect
                const angle = (flowerCount / selectedSize) * Math.PI * 2;
                const spiralFactor = flowerCount / selectedSize;
                const radius = 100 * spiralFactor;
                const x = Math.cos(angle) * radius + 135;
                const y = Math.sin(angle) * radius + 135;
                
                const flowerElement = $(`
                    <div class="flower-in-bouquet" 
                         data-flower-id="${flowerId}"
                         style="background-image: url(${imageUrl});
                                left: ${x}px;
                                top: ${y}px;">
                    </div>
                `);
                
                $('.flowers-preview').append(flowerElement);
                
                // Animate flower appearance
                gsap.from(flowerElement, {
                    duration: 0.8,
                    scale: 0,
                    opacity: 0,
                    x: -100,
                    y: -100,
                    rotation: -180,
                    ease: "elastic.out(1, 0.5)"
                });
                
                // Setup drag for placed flowers
                setupBouquetFlowerInteractions(flowerElement);
                
                // Enable next button if we've reached the selected size
                if (flowerCount === selectedSize) {
                    $('#next-btn').prop('disabled', false);
                    
                    // Celebrate completion
                    celebrateFlowerCompletion();
                }
            }
        }
        
        // Celebrate when all flowers are added
        function celebrateFlowerCompletion() {
            // Heart animation
            gsap.to('.heart-animation', {
                duration: 1,
                scale: 1.5,
                opacity: 0,
                y: -50,
                stagger: 0.1,
                ease: "power1.out"
            });
            
            // Bouquet pulse
            gsap.to('.bouquet-circle', {
                duration: 0.5,
                scale: 1.05,
                repeat: 1,
                yoyo: true,
                ease: "elastic.out(1, 0.5)"
            });
        }
        
        // Setup interactions for flowers in bouquet
        function setupBouquetFlowerInteractions(element) {
            interact(element.get(0)).draggable({
                restrict: {
                    restriction: '.flowers-preview',
                    elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
                },
                onmove: dragMoveListener
            });
        }
        
        // Drag movement handler with smooth animation
        function dragMoveListener(event) {
            const target = event.target;
            const x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
            const y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;
            
            gsap.to(target, {
                duration: 0.1,
                x: x,
                y: y,
                ease: "power1.out",
                onUpdate: function() {
                    target.setAttribute('data-x', x);
                    target.setAttribute('data-y', y);
                }
            });
        }
        
        // Check if over bouquet area
        function isOverBouquet(event) {
            const bouquetRect = $('.flowers-preview')[0].getBoundingClientRect();
            return (
                event.clientX >= bouquetRect.left &&
                event.clientX <= bouquetRect.right &&
                event.clientY >= bouquetRect.top &&
                event.clientY <= bouquetRect.bottom
            );
        }
        
        // Show summary with animations
        function showSummary() {
            calculateTotal().then(total => {
                let html = `
                    <div class="summary-content">
                        <div class="summary-item">
                            <span class="summary-label">Bouquet Size:</span>
                            <span class="summary-value">${selectedSize} Flowers</span>
                        </div>
                        <div class="summary-item">
                            <span class="summary-label">Total Price:</span>
                            <span class="summary-value price">${total} ${CURRENCY}</span>
                        </div>
                        <div class="flower-summary">
                            <h5>Your Flowers:</h5>
                            <ul id="flower-list"></ul>
                        </div>
                    </div>
                    <div class="edit-options">
                        <button class="btn btn-edit" id="edit-cover">
                            <svg viewBox="0 0 24 24">
                                <path d="M20.71,7.04C21.1,6.65 21.1,6 20.71,5.63L18.37,3.29C18,2.9 17.35,2.9 16.96,3.29L15.12,5.12L18.87,8.87M3,17.25V21H6.75L17.81,9.93L14.06,6.18L3,17.25Z" />
                            </svg>
                            Edit Cover
                        </button>
                        <button class="btn btn-edit" id="edit-flowers">
                            <svg viewBox="0 0 24 24">
                                <path d="M12,2C13.1,2 14,2.9 14,4C14,5.1 13.1,6 12,6C10.9,6 10,5.1 10,4C10,2.9 10.9,2 12,2M15.5,8C16.3,8 17,8.7 17,9.5C17,10.3 16.3,11 15.5,11C14.7,11 14,10.3 14,9.5C14,8.7 14.7,8 15.5,8M8.5,8C9.3,8 10,8.7 10,9.5C10,10.3 9.3,11 8.5,11C7.7,11 7,10.3 7,9.5C7,8.7 7.7,8 8.5,8M3.5,11C4.3,11 5,11.7 5,12.5C5,13.3 4.3,14 3.5,14C2.7,14 2,13.3 2,12.5C2,11.7 2.7,11 3.5,11M12,12C14.67,12 20,13.34 20,16V18H4V16C4,13.34 9.33,12 12,12Z" />
                            </svg>
                            Edit Flowers
                        </button>
                    </div>
                `;
                
                $('.summary-details').html(html);
                loadFlowerSummary();
                
                // Animate summary appearance
                gsap.from('.summary-content', {
                    duration: 0.5,
                    y: 20,
                    opacity: 0,
                    stagger: 0.1,
                    ease: "power2.out"
                });
                
                // Replace next button with add to cart
                $('#next-btn').hide();
                if ($('#add-to-cart-btn').length === 0) {
                    $('<button id="add-to-cart-btn" class="btn">Add to Cart</button>')
                        .insertAfter('#next-btn')
                        .on('click', addToCart);
                    
                    // Animate button appearance
                    gsap.from('#add-to-cart-btn', {
                        duration: 0.5,
                        y: 20,
                        opacity: 0,
                        ease: "back.out"
                    });
                }
                
                // Edit button handlers
                $('#edit-cover').on('click', () => navigateToStep(1));
                $('#edit-flowers').on('click', () => navigateToStep(3));
            });
        }
        
        // Load flower summary with counts
        function loadFlowerSummary() {
            const flowerCounts = getFlowerCounts();
            const flowerIds = Object.keys(flowerCounts);
            
            if (flowerIds.length === 0) {
                $('#flower-list').html('<li>No flowers selected</li>');
                return;
            }
            
            $.get(`api/get_flowers.php?ids=${flowerIds.join(',')}`, function(response) {
                if (response.success && response.data) {
                    let html = '';
                    response.data.forEach(flower => {
                        const count = flowerCounts[flower.id];
                        html += `
                            <li>
                                <span class="flower-name">${flower.name}</span>
                                <span class="flower-count">${count}x</span>
                            </li>
                        `;
                    });
                    $('#flower-list').html(html);
                }
            });
        }
        
        // Get flower counts
        function getFlowerCounts() {
            const counts = {};
            selectedFlowers.forEach(id => {
                counts[id] = (counts[id] || 0) + 1;
            });
            return counts;
        }
        
        // Calculate total price with romantic loading effect
        async function calculateTotal() {
            try {
                // Show loading effect
                gsap.to('.price', {
                    duration: 0.5,
                    opacity: 0.5,
                    y: -5,
                    repeat: 3,
                    yoyo: true,
                    ease: "power1.inOut"
                });
                
                // Get cover price
                const coverResponse = await $.get(`api/get_bouquet_cover.php?id=${selectedCover}`);
                if (!coverResponse || !coverResponse.price) {
                    throw new Error('Could not get cover price');
                }
                const coverPrice = parseFloat(coverResponse.price);
                
                // Get flower prices
                const flowerCounts = getFlowerCounts();
                const flowerIds = Object.keys(flowerCounts);
                let flowersPrice = 0;
                
                if (flowerIds.length > 0) {
                    const flowerResponse = await $.get(`api/get_flowers.php?ids=${flowerIds.join(',')}`);
                    if (flowerResponse.success && flowerResponse.data) {
                        flowerResponse.data.forEach(flower => {
                            flowersPrice += parseFloat(flower.price_per_unit) * flowerCounts[flower.id];
                        });
                    }
                }
                
                // Calculate total with 30% arrangement fee
                const total = coverPrice + flowersPrice + (flowersPrice * 0.3);
                return parseFloat(total.toFixed(2));
            } catch (error) {
                console.error("Error calculating total:", error);
                return 0;
            }
        }
        
        // Add to cart with romantic celebration
        async function addToCart() {
            try {
                // Calculate total price
                const totalPrice = await calculateTotal();
                if (totalPrice <= 0) {
                    throw new Error('Invalid total price calculation');
                }
                
                // Prepare flower counts
                const flowerCounts = getFlowerCounts();
                const flowersArray = Object.keys(flowerCounts).map(id => ({
                    id: parseInt(id),
                    quantity: flowerCounts[id]
                }));
                
                // Show loading state with romantic theme
                const swalInstance = Swal.fire({
                    title: 'Creating Your Bouquet',
                    html: '<div class="swal-romantic-loading"><div class="heart-pulse"></div><p>We\'re preparing your special gift with love...</p></div>',
                    allowOutsideClick: false,
                    showConfirmButton: false,
                    background: 'var(--light-color)',
                    backdrop: `
                        rgba(255, 214, 224, 0.8)
                        url("${BASE_URL}/assets/images/heart-pattern.jpg")
                        center top
                        repeat
                    `
                });
                
                // Determine correct API path
                const apiPath = 'api/add_custom_bouquet.php';
                
                // Send request
                const response = await $.ajax({
                    url: apiPath,
                    type: 'POST',
                    contentType: 'application/json',
                    data: JSON.stringify({
                        cover_id: selectedCover,
                        flower_count: selectedSize,
                        flowers: flowersArray,
                        total_price: totalPrice
                    })
                });
                
                // Close loading state
                await swalInstance.close();
                
                if (response.success) {
                    // Show success with romantic animation
                    await Swal.fire({
                        icon: 'success',
                        title: 'Bouquet Added with Love!',
                        text: 'Your custom bouquet has been added to your cart',
                        showConfirmButton: false,
                        timer: 1500,
                        background: 'var(--light-color)',
                        backdrop: `
                            rgba(255, 214, 224, 0.8)
                            url("${BASE_URL}/assets/images/heart-pattern.jpg")
                            center top
                            repeat
                        `
                    });
                    
                    // Trigger confetti celebration
                    triggerRomanticConfetti();
                    
                    // Update cart count
                    if (response.cart_count) {
                        updateCartCount(response.cart_count);
                    }
                    
                    // Redirect to cart after delay
                    setTimeout(() => {
                        window.location.href = 'cart.php';
                    }, 2000);
                } else {
                    throw new Error(response.message || 'Failed to add to cart');
                }
            } catch (error) {
                console.error('Error adding to cart:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: error.message || 'Could not add to cart. Please try again.',
                    confirmButtonText: 'OK',
                    background: 'var(--light-color)'
                });
            }
        }
        
        // Trigger romantic confetti effect
        function triggerRomanticConfetti() {
            $('.confetti-container').show();
            const colors = ['#ff6b8b', '#ffb8c6', '#ff9eb5', '#ff4757', '#ff8fab'];
            
            for (let i = 0; i < 100; i++) {
                const confetti = $('<div class="confetti"></div>');
                $('.confetti-container').append(confetti);
                
                // Random properties
                const size = Math.random() * 10 + 5;
                const color = colors[Math.floor(Math.random() * colors.length)];
                const left = Math.random() * 100;
                const delay = Math.random() * 5;
                const duration = Math.random() * 3 + 3;
                
                // Apply styles
                confetti.css({
                    width: size + 'px',
                    height: size + 'px',
                    backgroundColor: color,
                    left: left + '%',
                    borderRadius: size > 8 ? '50%' : '0',
                    transform: 'rotate(' + (Math.random() * 360) + 'deg)'
                });
                
                // Animate
                gsap.to(confetti, {
                    y: '100vh',
                    x: (Math.random() - 0.5) * 100,
                    rotation: Math.random() * 360,
                    opacity: 0,
                    delay: delay,
                    duration: duration,
                    ease: "power1.in",
                    onComplete: function() {
                        confetti.remove();
                        if (i === 99) {
                            $('.confetti-container').hide();
                        }
                    }
                });
            }
        }
        
        // Update cart count
        function updateCartCount(count) {
            $('.cart-count').text(count);
            $('.header-cart-count').text(count);
            
            // Animate cart update
            gsap.from('.cart-count', {
                duration: 0.5,
                scale: 1.5,
                y: -10,
                ease: "elastic.out(1, 0.5)"
            });
        }
        
        // Navigate to specific step
        function navigateToStep(step) {
            currentStep = step;
            loadStep(currentStep);
            updateUI();
        }
        
        // Update UI elements
        function updateUI() {
            $('.step').removeClass('active');
            $(`.step[data-step="${currentStep}"]`).addClass('active');
            
            $('#prev-btn').toggle(currentStep > 1);
            
            if (currentStep === 4) {
                $('#next-btn').hide();
            } else {
                $('#next-btn').show().prop('disabled', !validateStep(currentStep));
            }
        }
        
        // Validate current step
        function validateStep(step) {
            switch(step) {
                case 1: return selectedCover !== null;
                case 2: return selectedSize !== null;
                case 3: return selectedFlowers.length === selectedSize;
                default: return true;
            }
        }
        
        // Show error message
        function showError(message) {
            $('.products-grid').html(`
                <div class="error-message">
                    <svg viewBox="0 0 24 24">
                        <path d="M13,13H11V7H13M13,17H11V15H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2Z" />
                    </svg>
                    <p>${message}</p>
                </div>
            `);
        }
        
        // Show info message
        function showMessage(message) {
            const toast = $(`
                <div class="romantic-toast">
                    <svg viewBox="0 0 24 24">
                        <path d="M12,2L4.5,20.29L5.21,21L12,18L18.79,21L19.5,20.29L12,2Z" />
                    </svg>
                    <span>${message}</span>
                </div>
            `);
            
            $('body').append(toast);
            
            gsap.from(toast, {
                duration: 0.3,
                y: 20,
                opacity: 0,
                ease: "back.out"
            });
            
            setTimeout(() => {
                gsap.to(toast, {
                    duration: 0.3,
                    y: -20,
                    opacity: 0,
                    onComplete: () => toast.remove()
                });
            }, 3000);
        }
        
        // Initialize the builder
        initBuilder();
        
        // Navigation buttons
        $('#next-btn').on('click', function() {
            if (currentStep < 4 && validateStep(currentStep)) {
                currentStep++;
                loadStep(currentStep);
                updateUI();
            }
        });
        
        $('#prev-btn').on('click', function() {
            if (currentStep > 1) {
                currentStep--;
                loadStep(currentStep);
                updateUI();
            }
        });
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>